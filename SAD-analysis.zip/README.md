# AI Scrum Master

S-AD in → clarifying questions, a traceable Epic/Feature/Story backlog, a
dependency-ordered sprint plan with a capacity forecast, semantic duplicate
detection on new stories, and a human-gated publish step.

Pure standard library at its core. FastAPI is needed only for the HTTP layer;
the LLM is optional and the whole pipeline runs deterministically without it.

```bash
python demo.py                  # end-to-end run on the built-in sample S-AD
python demo.py path/to/SAD.docx # your own architecture document
python tests/test_agent.py      # 15 checks, no pytest required
uvicorn ai_scrum_master.api:app --reload
```

## Where each capability lives

| Brief | Module | Entry point |
|---|---|---|
| Clarifying questions before generating | `clarify.py` | `clarifying_questions()` |
| **C1** S-AD → complete ticket set | `sad_parser.py`, `decomposer.py` | `decompose()` |
| **C2** SAFe hierarchy | `hierarchy.py` | `validate()`, `rollup_points()`, `tree()` |
| **C3** Dependency-ordered plan + forecast | `planner.py` | `infer_dependencies()`, `build_plan()` |
| **C4** New-story duplicate check | `dedupe.py` | `check_new_story()`, `confirm_and_create()` |
| Existing-board health check | `board.py` | `load_board()`, `health_check()` |
| Exports + publish gate | `export.py` | `export_all()`, `prepare_publish()`, `publish()` |
| Everything wired together | `pipeline.py`, `api.py` | `pipeline.run()` |
| Shared helpers (DoD, cycle detection, counting) | `common.py` | `dod_for()`, `find_cycles()` |

Install and run commands, including a full curl walkthrough for a judge, are in
[COMMANDS.md](COMMANDS.md).

## The declared ordering heuristic

**Layer-first, risk-weighted critical path.**

1. Dependencies are a hard constraint — a ticket never starts before every
   blocker has *finished* in an earlier sprint.
2. Ties broken by longest remaining downstream chain of points (unblock the
   most work first).
3. Then architectural layer: foundation → data → backend → integration →
   frontend → quality → security → release, so executing sprint-by-sprint
   actually builds the architecture bottom-up.
4. Then risk descending — de-risk while there is still time to react.
5. Then smallest story first, to fill leftover capacity instead of wasting it.

Dependencies come from three sources: the blueprint chain the decomposer
writes, structural rules (QA follows implementation, release closes the epic,
foundation enablers gate everything), and lexical producer/consumer rules —
which is why "Produce UI wireframes" always lands before "Implement UI
components in HTML/React", never the other way round. Cycles are broken against
layer order so the graph stays a DAG.

`planner.explain(backlog, ticket_id, plan)` answers "why is this here?" with the
S-AD reference, the blockers and the rule applied.

## Coverage beyond happy-path stories

Every Feature gets automated-test work; risk-bearing Features get a security and
compliance review; every Epic gets release readiness; the architecture gets
foundation enablers. If the S-AD has no security, quality or release section,
cross-cutting Epics are added and labelled as such, so the backlog spans
"we have an S-AD" to "we have a shippable service".

## Duplicate detection by meaning

Normalisation folds domain synonyms (ui/screen/frontend → interface,
login/sso → authentication, build/create/develop → implement), then TF-IDF
cosine is blended with token overlap, scored separately on title and body so a
one-line user story still matches a verbose blueprint ticket. Containment is
used when one side is much shorter, Jaccard otherwise — that stops two
templated tickets about different subjects reading as identical. An embedding
backend (ChromaDB, sentence-transformers) can be injected via the `embed`
argument and it blends into the same score.

Three outcomes, never two: `duplicate` (points at the existing ticket, creates
nothing), `needs_review` (hands the call to the human), `new` (proposes a parent
and a sprint, still asks first).

## Governance

- `confirm_and_create()` returns `None` unless `approved=True` — no ticket is
  created without a human.
- A sprint marked committed is copied into the plan verbatim; the packer never
  re-sequences it. New work goes to the first non-committed sprint with room,
  and the decision message says so.
- `prepare_publish()` is a dry run by construction. `publish()` refuses without
  an `approved_by` value and needs an explicitly injected transport, so there is
  no code path that reaches JIRA by accident.
- Issues are detected by logic — joins, graph checks, similarity — never by
  hard-coded record ids.

## Tuning

| Knob | Where | Effect |
|---|---|---|
| `min_leaf_tickets` | `pipeline.run()` | backlog size floor (default 100) |
| `duplicate_threshold` / `review_threshold` | `dedupe.check_new_story()` | 0.62 / 0.42 |
| `focus_factor`, `points_per_person_day`, `velocity` | `CapacityConfig` | sprint capacity |
| `holidays`, `TeamMember.days_off` | `CapacityConfig` | per-sprint capacity reduction |
| `ANTHROPIC_API_KEY`, `ASM_MODEL` | environment | turns the LLM path on |

## Wiring the real data pack

- Capacity, velocity and holidays from the synthetic `.xlsx` → build a
  `CapacityConfig` and pass it to `pipeline.run(capacity=...)`.
- The existing board → `board.load_board(path)` (xlsx needs `openpyxl`; csv and
  json need nothing) then `board.health_check()`.
- The `.docx` S-AD is read without external dependencies.
