# Commands

## 1. Install

```bash
cd ai-scrum-master
python3 -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

The core pipeline has zero third-party dependencies, so this also works:

```bash
python3 demo.py                      # no venv, no pip, nothing installed
```

Optional LLM path (titles and acceptance criteria get written by the model;
sequencing, dependencies and forecasting stay deterministic either way):

```bash
export ANTHROPIC_API_KEY=sk-...      # Windows: set ANTHROPIC_API_KEY=sk-...
export ASM_MODEL=claude-sonnet-4-6   # optional override
```

## 2. Run the demo

```bash
python3 demo.py                      # built-in sample S-AD
python3 demo.py /path/to/S-AD.docx   # your own architecture document
python3 demo.py /path/to/S-AD.md
```

Writes `out/backlog.csv`, `out/backlog_plan.json`, `out/sprint_plan.md`.

## 3. Tests

```bash
python3 tests/test_agent.py          # no pytest needed
pytest tests -q                      # if pytest is installed
```

## 4. API server

```bash
uvicorn ai_scrum_master.api:app --reload --port 8000
# interactive docs: http://localhost:8000/docs
```

### Judge-run walkthrough with curl

```bash
# clarifying questions before anything is generated
curl -s localhost:8000/intake/analyze \
  -H 'content-type: application/json' \
  -d '{"text":"1. Scope\nThe portal shall show vehicle health to dealers."}'

# generate the backlog + plan from a file (returns run_id)
curl -s -F 'file=@S-AD.docx' 'localhost:8000/backlog/generate/upload?min_leaf_tickets=100'

RUN=<run_id from above>

curl -s localhost:8000/backlog/$RUN/tree          # Epic -> Feature -> Story
curl -s localhost:8000/backlog/$RUN/readiness     # DoD / AC / estimate gate
curl -s localhost:8000/plan/$RUN                  # sprints + capacity forecast
curl -s localhost:8000/plan/$RUN/explain/STORY-0063   # why this sprint?
curl -s localhost:8000/export/$RUN                # csv + json + markdown

# duplicate check (returns decision_id and a verdict)
curl -s localhost:8000/stories/check -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"title\":\"Draw up the dealer portal screens\",\"points\":3}"

# human approval is the only way a ticket gets created
curl -s localhost:8000/stories/confirm -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"decision_id\":\"<id>\",\"approved\":true,\"approver\":\"you@team\"}"

# existing-board health check
curl -s -F 'file=@board.xlsx' localhost:8000/board/health

# publish: dry run, then explicit human-approved push
curl -s localhost:8000/publish/prepare -H 'content-type: application/json' -d "{\"run_id\":\"$RUN\"}"
curl -s localhost:8000/publish/confirm -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"approved_by\":\"you@team\"}"
```

## 5. Use it as a library

```python
from ai_scrum_master import pipeline, planner, dedupe, export

result = pipeline.run("S-AD.docx", min_leaf_tickets=100)
print(result.summary())
print(planner.explain(result.backlog, "STORY-0063", result.plan))
export.export_all(result.backlog, result.plan, "exports")
```
