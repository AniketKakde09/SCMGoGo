"""End-to-end demo: python demo.py [path/to/SAD.docx]

Runs every capability and writes exports to ./out.
"""

from __future__ import annotations

import sys
from pathlib import Path

from ai_scrum_master import board, dedupe, export, hierarchy, pipeline, planner

SAMPLE_SAD = """
1. Introduction and Scope
The Connected Vehicle Service Portal provides dealers and fleet operators with a single
view of vehicle health, service history and scheduled maintenance. The platform shall
support 5,000 concurrent dealer users across 14 markets with a 99.5% availability target.

2. Deployment and Infrastructure
The solution is deployed on managed Kubernetes with infrastructure defined as code.
The pipeline must build, test and promote artefacts through dev, test and production.
Centralised logging, metrics and alerting shall be available from day one.

3. Data Architecture
The vehicle master data is sourced from the central telematics platform and cached locally.
The system shall store service events, maintenance plans and dealer entitlements.
Personal data of vehicle owners must be retained no longer than 24 months.

4. Backend Services
4.1 Vehicle Health Service
The service shall calculate a health score per vehicle from the latest diagnostic trouble codes.
It must expose the score and contributing factors through an authenticated API.
4.2 Maintenance Scheduling Service
The service shall propose maintenance slots based on mileage, time since last service and workshop capacity.
It must allow a dealer to confirm or reject a proposed slot.

5. Integration Layer
The platform integrates with the telematics event stream and with the dealer management system.
Events must be processed at least once with idempotent handling and a dead-letter queue.

6. User Interface
The dealer portal shall provide a vehicle list, a vehicle detail view and a scheduling screen.
The UI must be responsive and meet WCAG 2.1 AA.

7. Security and Compliance
Access is controlled through the corporate identity provider with role-based permissions.
All access to owner data must be audited and the solution must satisfy GDPR requirements.
"""


def main() -> None:
    src = sys.argv[1] if len(sys.argv) > 1 else SAMPLE_SAD
    is_text = len(sys.argv) <= 1

    print("=" * 78)
    result = pipeline.run(src, is_text=is_text, min_leaf_tickets=100, use_llm=True)

    print("CLARIFYING QUESTIONS (agent asks before it generates):")
    for q in result.questions:
        flag = "BLOCKING" if q.blocking else "        "
        print(f"  [{flag}] {q.question}\n             why: {q.why_it_matters}")

    stats = hierarchy.stats(result.backlog)
    print("\nBACKLOG (Capability 1 + 2)")
    print(f"  epics={stats['epics']} features={stats['features']} leaves={stats['leaves']} "
          f"points={stats['total_points']}")
    print(f"  by category: {stats['by_category']}")
    print(f"  readiness issues: {len(result.issues)}")

    print("\nSPRINT PLAN (Capability 3)")
    print(f"  rule: {result.plan.ordering_rule[:100]}...")
    for s in result.plan.sprints[:6]:
        load = sum(result.backlog.by_id(t).points for t in s.ticket_ids)
        print(f"  Sprint {s.index:>2} {s.start}..{s.end}  {load:>3}/{s.capacity:<6} pts  "
              f"{len(s.ticket_ids)} tickets")
    if len(result.plan.sprints) > 6:
        print(f"  ... {len(result.plan.sprints) - 6} more sprints")
    f = result.plan.forecast
    print(f"  FORECAST: finishes in Sprint {f['completion_sprint']} on {f['completion_date']} "
          f"({f['total_points']} pts, {f['unscheduled_count']} unscheduled)")
    print(f"  plan problems: {result.plan_problems or 'none'}")

    ui_ticket = next((t for t in result.backlog.leaves
                      if t.layer == "frontend" and "components" in t.title.lower()), None)
    if ui_ticket:
        print("\nWHY IS THIS TICKET HERE? (transparency)")
        print("  " + planner.explain(result.backlog, ui_ticket.id, result.plan).replace("\n", "\n  "))

    print("\nNEW-STORY CHECK (Capability 4)")
    dup = dedupe.check_new_story(
        result.backlog,
        "Create wireframes for the dealer portal screens",
        "Sketch the vehicle list and detail screens before we build the UI.",
        plan=result.plan,
    )
    print(f"  [{dup.verdict.upper()}] {dup.message}")

    new = dedupe.check_new_story(
        result.backlog,
        "Send SMS reminders to owners 48 hours before a booked service",
        "Reduce no-shows at the workshop.",
        plan=result.plan,
    )
    print(f"  [{new.verdict.upper()}] {new.message}")
    print(f"  confirmation required: {new.confirmation_prompt}")
    created = dedupe.confirm_and_create(result.backlog, new, plan=result.plan,
                                        approved=True, approver="scrum.master@demo")
    print(f"  created after human approval: {created.id if created else 'nothing'}")

    print("\nEXISTING-BOARD HEALTH CHECK")
    report = board.health_check(result.backlog)
    print(f"  findings: {report['findings_by_code']}")
    print(f"  refinement queue: {report['refinement_queue'][:5]}")

    files = export.export_all(result.backlog, result.plan, "out")
    print(f"\nEXPORTS: {files}")

    payload = export.prepare_publish(result.backlog, result.plan)
    print(f"PUBLISH (dry run): {payload['issue_count']} issues staged, "
          f"dry_run={payload['dry_run']}")
    print("PUBLISH without approval:", export.publish(payload, approved_by=None)["reason"])
    print("=" * 78)


if __name__ == "__main__":
    main()
