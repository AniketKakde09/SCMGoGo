"""Run with: python -m pytest tests -q   (or: python tests/test_agent.py)"""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ai_scrum_master import board, dedupe, export, hierarchy, pipeline, planner  # noqa: E402
from ai_scrum_master.models import TicketType  # noqa: E402
from demo import SAMPLE_SAD  # noqa: E402

RESULT = pipeline.run(SAMPLE_SAD, is_text=True, min_leaf_tickets=100, use_llm=False)


def test_asks_clarifying_questions():
    assert RESULT.questions, "agent must ask at least one clarifying question"


def test_produces_at_least_100_leaf_tickets():
    assert len(RESULT.backlog.leaves) >= 100


def test_every_ticket_traces_to_the_sad():
    assert all(t.sad_ref for t in RESULT.backlog.tickets)


def test_hierarchy_is_valid_and_estimable():
    assert RESULT.issues == [], RESULT.issues[:3]
    assert RESULT.backlog.of_type(TicketType.EPIC)
    assert all(t.points > 0 and t.acceptance_criteria and t.definition_of_done
               for t in RESULT.backlog.leaves)


def test_non_functional_work_is_covered():
    categories = hierarchy.stats(RESULT.backlog)["by_category"]
    for required in ("qa", "security", "release", "enabler"):
        assert categories.get(required, 0) > 0, f"missing {required} work"


def test_dependencies_are_respected_by_the_plan():
    assert RESULT.plan_problems == [], RESULT.plan_problems[:3]
    index = {t.id: t for t in RESULT.backlog.leaves}
    for t in RESULT.backlog.leaves:
        for dep in t.depends_on:
            d = index.get(dep)
            if d and t.sprint and d.sprint:
                assert d.sprint < t.sprint, f"{t.id} scheduled before its blocker {dep}"


def test_wireframes_precede_ui_implementation():
    wire = [t for t in RESULT.backlog.leaves if "wireframes for" in t.title.lower()]
    build = [t for t in RESULT.backlog.leaves if "components in html" in t.title.lower()]
    assert wire and build
    assert max(t.sprint for t in wire) <= min(t.sprint for t in build)


def test_forecast_completes_all_work():
    f = RESULT.plan.forecast
    assert f["unscheduled_count"] == 0
    assert f["completion_sprint"] and f["completion_date"]


def test_no_sprint_is_overcommitted():
    index = {t.id: t for t in RESULT.backlog.leaves}
    for s in RESULT.plan.sprints:
        load = sum(index[t].points for t in s.ticket_ids)
        assert load <= s.capacity * 1.05 or len(s.ticket_ids) == 1


def test_semantic_duplicate_is_caught_without_exact_text():
    existing = next(t for t in RESULT.backlog.leaves if "wireframes for" in t.title.lower())
    subject = existing.title.split("for", 1)[1].strip()
    decision = dedupe.check_new_story(
        RESULT.backlog, f"Draw up the screens for {subject}",
        "Mock up the layout before development starts.", plan=RESULT.plan,
    )
    assert decision.verdict in {"duplicate", "needs_review"}
    assert decision.matches


def test_genuinely_new_story_is_placed_but_needs_approval():
    decision = dedupe.check_new_story(
        RESULT.backlog, "Send SMS reminders 48 hours before a booked service",
        "Reduce workshop no-shows.", plan=RESULT.plan,
    )
    assert decision.verdict == "new"
    assert decision.requires_confirmation and decision.confirmation_prompt
    assert dedupe.confirm_and_create(RESULT.backlog, decision, plan=RESULT.plan,
                                     approved=False, approver="x") is None


def test_committed_sprint_is_never_resequenced():
    first = RESULT.plan.sprints[0]
    committed = {1: list(first.ticket_ids)}
    replanned = pipeline.run(SAMPLE_SAD, is_text=True, use_llm=False,
                             committed_sprints=committed)
    assert replanned.plan.sprints[0].ticket_ids == committed[1]
    assert replanned.plan.sprints[0].committed


def test_nothing_publishes_without_human_approval():
    payload = export.prepare_publish(RESULT.backlog, RESULT.plan)
    assert payload["dry_run"] and payload["requires_human_approval"]
    assert export.publish(payload, approved_by=None)["published"] is False


def test_board_health_check_finds_issues_by_logic():
    report = board.health_check(RESULT.backlog)
    assert report["ticket_count"] > 0
    assert "findings_by_code" in report and isinstance(report["sprint_balance"], list)


def test_explanation_names_the_rule_and_the_blockers():
    t = next(t for t in RESULT.backlog.leaves if t.depends_on)
    text = planner.explain(RESULT.backlog, t.id, RESULT.plan)
    assert "Blocked by" in text and "Rule applied" in text and t.sad_ref in text


if __name__ == "__main__":
    passed = failed = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                passed += 1
                print(f"PASS {name}")
            except AssertionError as exc:
                failed += 1
                print(f"FAIL {name}: {exc}")
    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)
