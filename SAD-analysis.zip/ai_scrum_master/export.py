"""Exports (CSV / JSON / Markdown) and the human-gated publish step.

Nothing reaches JIRA or Confluence until `publish()` is called with
`approved_by` set by a real human action in the UI. `prepare_publish()` builds
the payload and is always safe to call — it is a dry run by construction.
"""

from __future__ import annotations

import csv
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from .models import Backlog, TicketType
from .planner import Plan

CSV_COLUMNS = [
    "id", "type", "title", "parent_id", "epic", "sad_ref", "layer", "category",
    "points", "risk", "sprint", "depends_on", "acceptance_criteria",
    "definition_of_done", "rationale", "status",
]


def _epic_of(backlog: Backlog, ticket_id: str) -> str:
    seen: set[str] = set()
    t = backlog.by_id(ticket_id)
    while t and t.parent_id and t.id not in seen:
        seen.add(t.id)
        t = backlog.by_id(t.parent_id)
    return t.title if t and t.type is TicketType.EPIC else ""


def to_csv(backlog: Backlog, path: str | Path) -> Path:
    path = Path(path)
    with path.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for t in backlog.tickets:
            w.writerow({
                "id": t.id, "type": t.type.value, "title": t.title,
                "parent_id": t.parent_id or "", "epic": _epic_of(backlog, t.id),
                "sad_ref": t.sad_ref or "", "layer": t.layer, "category": t.category.value,
                "points": t.points, "risk": t.risk, "sprint": t.sprint or "",
                "depends_on": ";".join(t.depends_on),
                "acceptance_criteria": " | ".join(t.acceptance_criteria),
                "definition_of_done": " | ".join(t.definition_of_done),
                "rationale": t.rationale, "status": t.status,
            })
    return path


def to_json(backlog: Backlog, plan: Plan | None, path: str | Path) -> Path:
    path = Path(path)
    payload: dict[str, Any] = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "backlog": backlog.to_dict(),
    }
    if plan:
        payload["plan"] = plan.to_dict()
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def to_markdown(backlog: Backlog, plan: Plan, path: str | Path) -> Path:
    path = Path(path)
    lines = ["# Sprint plan", "", f"**Ordering rule:** {plan.ordering_rule}", ""]
    f = plan.forecast
    lines += [
        f"- Tickets: {len(backlog.leaves)} leaves across {len(backlog.of_type(TicketType.EPIC))} epics",
        f"- Total points: {f['total_points']}",
        f"- Forecast completion: Sprint {f['completion_sprint']} ({f['completion_date']})",
        "",
    ]
    for s in plan.sprints:
        load = sum(backlog.by_id(t).points for t in s.ticket_ids if backlog.by_id(t))
        lines.append(f"## {s.name} — {s.start} to {s.end} ({load}/{s.capacity} pts)")
        for tid in s.ticket_ids:
            t = backlog.by_id(tid)
            if not t:
                continue
            blockers = f" ← {', '.join(t.depends_on[:3])}" if t.depends_on else ""
            lines.append(f"- **{t.id}** [{t.points}] {t.title} _({t.sad_ref})_{blockers}")
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def export_all(backlog: Backlog, plan: Plan, out_dir: str | Path) -> dict[str, str]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    return {
        "csv": str(to_csv(backlog, out / "backlog.csv")),
        "json": str(to_json(backlog, plan, out / "backlog_plan.json")),
        "markdown": str(to_markdown(backlog, plan, out / "sprint_plan.md")),
    }


# --------------------------------------------------------------------------- #
# publish gate
# --------------------------------------------------------------------------- #
def prepare_publish(backlog: Backlog, plan: Plan | None = None) -> dict[str, Any]:
    """Build the JIRA-shaped payload. Always a dry run — writes nothing."""
    issues = []
    for t in backlog.tickets:
        issues.append({
            "externalId": t.id,
            "issueType": t.type.value,
            "summary": t.title,
            "description": t.description,
            "parentExternalId": t.parent_id,
            "storyPoints": t.points,
            "labels": [t.layer, t.category.value],
            "sprint": t.sprint,
            "customFields": {"sadReference": t.sad_ref, "orderingRationale": t.rationale},
            "acceptanceCriteria": t.acceptance_criteria,
            "definitionOfDone": t.definition_of_done,
            "dependsOn": t.depends_on,
        })
    return {
        "dry_run": True,
        "target": "sandbox-jira",
        "issue_count": len(issues),
        "sprint_count": len(plan.sprints) if plan else 0,
        "issues": issues,
        "requires_human_approval": True,
    }


def publish(
    payload: dict[str, Any],
    *,
    approved_by: str | None,
    transport: Callable[[dict[str, Any]], dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Actually push. Refuses without an explicit human approver."""
    if not approved_by:
        return {
            "published": False,
            "reason": "No human approval recorded. Nothing was written to JIRA/Confluence.",
        }
    body = dict(payload, dry_run=False, approved_by=approved_by,
                approved_at=datetime.now().isoformat(timespec="seconds"))
    if transport is None:
        return {"published": False, "reason": "No sandbox transport configured.",
                "would_have_sent": body["issue_count"], "approved_by": approved_by}
    result = transport(body)
    return {"published": True, "approved_by": approved_by, "result": result}
