"""Thin optional Groq LLM adapter.

The whole pipeline remains deterministic without the LLM.
If GROQ_API_KEY is configured and the Groq SDK is installed,
the decomposer/clarifier can use Groq for richer output.

If Groq is unavailable, every call returns None and callers
fall back to the local rule engine.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any


# Groq model can be overridden through environment variable.
MODEL = os.environ.get(
    "ASM_MODEL",
    "llama-3.3-70b-versatile",
)


def available() -> bool:
    """Return True only when Groq is configured and SDK is installed."""

    if not os.environ.get("GROQ_API_KEY"):
        return False

    try:
        import groq  # noqa: F401
    except ImportError:
        return False

    return True


def complete(
    prompt: str,
    *,
    system: str = "",
    max_tokens: int = 4000,
) -> str | None:
    """Send a prompt to Groq and return text response.

    Returns None on configuration, SDK, network, rate-limit,
    authentication, or API errors so the pipeline can fall back
    to deterministic processing.
    """

    if not available():
        return None

    try:
        from groq import Groq

        client = Groq(
            api_key=os.environ["GROQ_API_KEY"],
        )

        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "system",
                    "content": (
                        system
                        or "You are a senior Scrum Master and solution architect."
                    ),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            max_tokens=max_tokens,
            temperature=0,
        )

        return response.choices[0].message.content or ""

    except Exception:
        # Keep the pipeline resilient.
        # Local/rule-based processing remains the fallback.
        return None


def complete_json(
    prompt: str,
    *,
    system: str = "",
    max_tokens: int = 4000,
) -> Any | None:
    """Execute an LLM request and safely parse JSON."""

    raw = complete(
        prompt
        + "\n\n"
        + "Respond with JSON only. "
        + "Do not include prose. "
        + "Do not use markdown fences.",
        system=system,
        max_tokens=max_tokens,
    )

    if not raw:
        return None

    cleaned = raw.strip()

    # Remove markdown JSON fences if the model ignores the instruction.
    cleaned = re.sub(
        r"^```(?:json)?\s*",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )

    cleaned = re.sub(
        r"\s*```$",
        "",
        cleaned,
        flags=re.IGNORECASE,
    )

    cleaned = cleaned.strip()

    try:
        return json.loads(cleaned)

    except json.JSONDecodeError:
        # Try extracting the first JSON object/array.
        match = re.search(
            r"(\[.*\]|\{.*\})",
            cleaned,
            flags=re.DOTALL,
        )

        if not match:
            return None

        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            return None