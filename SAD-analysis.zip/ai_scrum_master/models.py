"""Domain models for the AI Scrum Master.

Everything downstream (hierarchy, sequencing, sprint packing, dedupe, export)
operates on these dataclasses, so the decomposer can be swapped between an LLM
and the rule engine without touching the rest of the pipeline.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class TicketType(str, Enum):
    EPIC = "Epic"
    FEATURE = "Feature"
    STORY = "Story"
    TASK = "Task"
    SPIKE = "Spike"


class Category(str, Enum):
    """Why a ticket exists. Used to guarantee non-functional coverage."""

    FUNCTIONAL = "functional"
    ENABLER = "enabler"
    QA = "qa"
    SECURITY = "security"
    COMPLIANCE = "compliance"
    RELEASE = "release"


# Architectural layer -> ordering weight. Lower builds first.
LAYER_ORDER: dict[str, int] = {
    "foundation": 0,
    "data": 1,
    "backend": 2,
    "integration": 3,
    "frontend": 4,
    "quality": 5,
    "security": 6,
    "release": 7,
}


@dataclass
class SADSection:
    """One addressable chunk of the System Architecture Document."""

    id: str                    # e.g. "SAD-4.2"
    title: str
    body: str
    layer: str = "backend"
    level: int = 1

    @property
    def ref(self) -> str:
        return f"{self.id} {self.title}"


@dataclass
class Ticket:
    id: str
    title: str
    type: TicketType
    description: str = ""
    parent_id: str | None = None
    sad_ref: str | None = None          # traceability: which S-AD section motivates this
    layer: str = "backend"
    category: Category = Category.FUNCTIONAL
    points: int = 3
    acceptance_criteria: list[str] = field(default_factory=list)
    definition_of_done: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    risk: int = 1                        # 1 low .. 5 high; feeds risk-first tiebreak
    sprint: int | None = None
    rationale: str = ""                  # human-readable "why it sits here"
    source: str = "sad"                  # sad | user | board
    status: str = "draft"                # draft | planned | committed | published

    @property
    def layer_rank(self) -> int:
        return LAYER_ORDER.get(self.layer, 2)

    def text(self) -> str:
        """Canonical text used for semantic duplicate detection."""
        return " ".join([self.title, self.description, *self.acceptance_criteria])

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["type"] = self.type.value
        d["category"] = self.category.value
        return d


@dataclass
class Backlog:
    tickets: list[Ticket] = field(default_factory=list)
    sad_sections: list[SADSection] = field(default_factory=list)

    def by_id(self, ticket_id: str) -> Ticket | None:
        return next((t for t in self.tickets if t.id == ticket_id), None)

    def children_of(self, ticket_id: str) -> list[Ticket]:
        return [t for t in self.tickets if t.parent_id == ticket_id]

    def of_type(self, *types: TicketType) -> list[Ticket]:
        return [t for t in self.tickets if t.type in types]

    @property
    def leaves(self) -> list[Ticket]:
        """Stories / Tasks / Spikes — the only things that consume capacity."""
        return self.of_type(TicketType.STORY, TicketType.TASK, TicketType.SPIKE)

    def add(self, ticket: Ticket) -> Ticket:
        self.tickets.append(ticket)
        return ticket

    def to_dict(self) -> dict[str, Any]:
        return {
            "tickets": [t.to_dict() for t in self.tickets],
            "sad_sections": [asdict(s) for s in self.sad_sections],
        }


@dataclass
class TeamMember:
    name: str
    role: str = "Engineer"
    allocation: float = 1.0       # FTE fraction on this team
    days_off: list[dt.date] = field(default_factory=list)


@dataclass
class CapacityConfig:
    """Everything needed to turn a ticket order into a dated forecast."""

    start_date: dt.date
    sprint_length_days: int = 10          # working days
    members: list[TeamMember] = field(default_factory=list)
    velocity: float | None = None         # points/sprint at full capacity; derived if None
    points_per_person_day: float = 0.8
    focus_factor: float = 0.8
    holidays: list[dt.date] = field(default_factory=list)
    max_sprints: int = 40

    def nominal_velocity(self) -> float:
        if self.velocity is not None:
            return float(self.velocity)
        fte = sum(m.allocation for m in self.members) or 1.0
        return fte * self.sprint_length_days * self.points_per_person_day * self.focus_factor

    def sprint_window(self, index: int) -> tuple[dt.date, dt.date]:
        """Calendar window for sprint `index` (1-based), skipping weekends."""
        start = _add_working_days(self.start_date, (index - 1) * self.sprint_length_days)
        end = _add_working_days(start, self.sprint_length_days - 1)
        return start, end

    def capacity_for(self, index: int) -> float:
        """Nominal velocity reduced by holidays and personal days in the window."""
        start, end = self.sprint_window(index)
        working = _working_days_between(start, end)
        if not working:
            return 0.0
        team_days = 0.0
        for m in self.members or [TeamMember("Unassigned")]:
            off = set(m.days_off) | set(self.holidays)
            team_days += sum(m.allocation for d in working if d not in off)
        full_team_days = (sum(m.allocation for m in self.members) or 1.0) * len(working)
        ratio = team_days / full_team_days if full_team_days else 1.0
        return round(self.nominal_velocity() * ratio, 2)


@dataclass
class Sprint:
    index: int
    start: dt.date
    end: dt.date
    capacity: float
    ticket_ids: list[str] = field(default_factory=list)
    committed: bool = False

    @property
    def name(self) -> str:
        return f"Sprint {self.index}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "name": self.name,
            "start": self.start.isoformat(),
            "end": self.end.isoformat(),
            "capacity": self.capacity,
            "ticket_ids": list(self.ticket_ids),
            "committed": self.committed,
        }


def _add_working_days(start: dt.date, n: int) -> dt.date:
    d = start
    while d.weekday() >= 5:
        d += dt.timedelta(days=1)
    added = 0
    while added < n:
        d += dt.timedelta(days=1)
        if d.weekday() < 5:
            added += 1
    return d


def _working_days_between(start: dt.date, end: dt.date) -> list[dt.date]:
    out: list[dt.date] = []
    d = start
    while d <= end:
        if d.weekday() < 5:
            out.append(d)
        d += dt.timedelta(days=1)
    return out

