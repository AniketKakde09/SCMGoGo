"""Ask hard questions before generating anything.

A good Scrum Master refuses to estimate mush. Given raw demand (a one-liner, a
PRD, workshop notes, an S-AD) this returns the questions whose answers would
actually change the backlog — ranked, with the reason each one matters.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Any

from . import llm
from .models import SADSection

_PROBES: list[tuple[str, re.Pattern, str, str]] = [
    ("users", re.compile(r"\b(user|persona|actor|role|customer|dealer|technician)\b", re.I),
     "Who exactly uses this, and which of them is the primary persona for v1?",
     "Scope and UI stories change completely per persona."),
    ("scale", re.compile(r"\b(users?/|throughput|tps|rps|volume|concurrent|scal|load|sla)\b", re.I),
     "What load and response-time targets must this meet at go-live?",
     "Drives caching, async processing and the performance test stories."),
    ("data", re.compile(r"\b(data|record|entity|schema|master data|source of truth)\b", re.I),
     "Which system is the source of truth for the core data, and is any of it PII?",
     "Determines data-layer effort, GDPR/TISAX stories and retention rules."),
    ("integration", re.compile(r"\b(integrat|api|interface|downstream|upstream|sap|jira|kafka)\b", re.I),
     "Which external systems must this talk to, and are their contracts stable and available?",
     "Integration contracts are the most common hidden critical path."),
    ("auth", re.compile(r"\b(auth|login|sso|permission|role-based|rbac|identity)\b", re.I),
     "What identity provider and authorization model applies?",
     "Security stories cannot be estimated without it."),
    ("compliance", re.compile(r"\b(gdpr|compliance|regulat|audit|retention|legal|tisax)\b", re.I),
     "Which regulations or internal policies apply, and who signs off compliance?",
     "Adds mandatory, non-negotiable scope and an approval gate."),
    ("nfr", re.compile(r"\b(availability|uptime|recovery|rto|rpo|resilien|failover)\b", re.I),
     "What availability and recovery targets apply (RTO/RPO)?",
     "Decides whether resilience is a story or an architecture."),
    ("release", re.compile(r"\b(release|launch|go-live|milestone|deadline|pilot)\b", re.I),
     "What is the fixed date or milestone, and what is the minimum shippable slice?",
     "Without it the forecast has no failure condition."),
    ("done", re.compile(r"\b(success|kpi|metric|outcome|benefit|adoption)\b", re.I),
     "How will we know this succeeded — which measurable outcome?",
     "Separates the must-have slice from the nice-to-have backlog tail."),
]


@dataclass
class Question:
    topic: str
    question: str
    why_it_matters: str
    blocking: bool = False

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def clarifying_questions(
    sections: list[SADSection], *, max_questions: int = 5, use_llm: bool = True
) -> list[Question]:
    text = "\n".join(f"{s.title}\n{s.body}" for s in sections)

    gaps = [
        Question(topic, q, why, blocking=topic in {"data", "integration", "release"})
        for topic, pattern, q, why in _PROBES
        if not pattern.search(text)
    ]
    has_children = {
        a.id for a, b in zip(sections, sections[1:]) if b.level > a.level
    }
    thin = [
        Question(
            "ambiguity",
            f"Section '{s.title}' carries almost no detail — what behaviour does it actually require?",
            "Too thin to decompose into estimable stories without guessing.",
            blocking=True,
        )
        for s in sections
        if len(s.body) < 120 and s.id not in has_children
    ][:2]

    questions = (gaps + thin)[:max_questions]

    if use_llm and llm.available():
        data = llm.complete_json(
            "You are a Scrum Master reviewing incoming demand before backlog creation. "
            "List the questions whose answers would most change the resulting backlog. "
            'Return JSON: [{"topic": "...", "question": "...", "why_it_matters": "...", "blocking": true}]\n\n'
            f"{text[:6000]}",
            max_tokens=1200,
        )
        if isinstance(data, list) and data:
            questions = [
                Question(
                    str(d.get("topic", "scope"))[:40],
                    str(d.get("question", ""))[:300],
                    str(d.get("why_it_matters", ""))[:300],
                    bool(d.get("blocking", False)),
                )
                for d in data[:max_questions]
                if d.get("question")
            ] or questions

    if not questions:
        questions = [
            Question(
                "slice",
                "What is the smallest slice that would be genuinely useful in production?",
                "Lets us sequence for value instead of building the whole architecture before anyone sees it.",
            )
        ]
    return questions
