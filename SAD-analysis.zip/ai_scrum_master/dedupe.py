"""Capability 4 — new-story check before ticket creation.

Detects duplicates by *meaning*, not exact text:

  1. normalisation + domain synonym folding (ui == user interface == frontend,
     auth == authentication == login, ...)
  2. TF-IDF cosine over the whole backlog (pure Python, zero dependencies)
  3. token-set containment, which catches "Build login screen" vs
     "Implement the login screen UI"
  4. optional embedding backend (ChromaDB / sentence-transformers) if present

Outcomes are deliberately three-way: DUPLICATE (do not create),
NEEDS_REVIEW (ask the human), NEW (propose placement, still ask before
touching a committed sprint).
"""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from .common import dod_for
from .models import Backlog, Category, Sprint, Ticket, TicketType
from .planner import Plan

_SYNONYMS = {
    "ui": "interface", "ux": "interface", "frontend": "interface", "front-end": "interface",
    "screen": "interface", "page": "interface", "gui": "interface",
    "auth": "authentication", "login": "authentication", "signin": "authentication",
    "sign-in": "authentication", "sso": "authentication",
    "db": "database", "datastore": "database", "persistence": "database", "schema": "database",
    "endpoint": "api", "rest": "api", "service": "api", "route": "api",
    "spec": "specification", "docs": "documentation", "doc": "documentation",
    "e2e": "test", "qa": "test", "testing": "test", "tests": "test",
    "ci": "pipeline", "cd": "pipeline", "cicd": "pipeline", "build": "pipeline",
    "monitoring": "observability", "logging": "observability", "metrics": "observability",
    "create": "implement", "build": "implement", "develop": "implement", "add": "implement",
    "make": "implement", "code": "implement", "write": "implement",
}

_STOP = {
    "the", "a", "an", "of", "for", "to", "and", "or", "in", "on", "with", "as", "by",
    "we", "i", "our", "it", "is", "be", "should", "must", "shall", "that", "this",
    "user", "story", "ticket", "able", "want", "need", "can", "so", "from", "into",
}

EmbedFn = Callable[[list[str]], list[list[float]]]


@dataclass
class Match:
    ticket_id: str
    title: str
    score: float
    reason: str
    sprint: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return self.__dict__.copy()


@dataclass
class IntakeDecision:
    verdict: str                       # duplicate | needs_review | new
    message: str
    matches: list[Match] = field(default_factory=list)
    proposed_ticket: dict[str, Any] | None = None
    proposed_parent: str | None = None
    proposed_sprint: int | None = None
    requires_confirmation: bool = True
    confirmation_prompt: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "verdict": self.verdict,
            "message": self.message,
            "matches": [m.to_dict() for m in self.matches],
            "proposed_ticket": self.proposed_ticket,
            "proposed_parent": self.proposed_parent,
            "proposed_sprint": self.proposed_sprint,
            "requires_confirmation": self.requires_confirmation,
            "confirmation_prompt": self.confirmation_prompt,
        }


# --------------------------------------------------------------------------- #
# text similarity
# --------------------------------------------------------------------------- #
def normalize(text: str) -> list[str]:
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    out: list[str] = []
    for w in words:
        w = _SYNONYMS.get(w, w)
        if w in _STOP or len(w) < 2:
            continue
        if len(w) > 4 and w.endswith("s") and not w.endswith("ss"):
            w = w[:-1]
        out.append(w)
    return out


class SimilarityIndex:
    """TF-IDF cosine index with an optional embedding backend."""

    def __init__(self, tickets: Iterable[Ticket], embed: EmbedFn | None = None) -> None:
        self.tickets = [t for t in tickets]
        self.docs = [normalize(t.text()) for t in self.tickets]
        self.titles = [normalize(t.title) for t in self.tickets]
        self.df: Counter[str] = Counter()
        for doc in self.docs:
            self.df.update(set(doc))
        self.n = max(1, len(self.docs))
        self.vectors = [self._vector(d) for d in self.docs]
        self.title_vectors = [self._vector(d) for d in self.titles]
        self.embed = embed
        self.embeddings = embed([t.text() for t in self.tickets]) if embed else None

    def _idf(self, term: str) -> float:
        return math.log((self.n + 1) / (self.df.get(term, 0) + 1)) + 1.0

    def _vector(self, doc: list[str]) -> dict[str, float]:
        tf = Counter(doc)
        vec = {term: (count / len(doc)) * self._idf(term) for term, count in tf.items()} if doc else {}
        norm = math.sqrt(sum(v * v for v in vec.values())) or 1.0
        return {k: v / norm for k, v in vec.items()}

    def query(self, text: str, title: str | None = None, top_k: int = 5) -> list[Match]:
        doc = normalize(text)
        qvec = self._vector(doc)
        qset = set(doc)
        qtitle = normalize(title) if title else doc
        qtvec = self._vector(qtitle)
        qtset = set(qtitle)
        scored: list[Match] = []

        qemb = self.embed([text])[0] if self.embed else None

        for i, t in enumerate(self.tickets):
            cos = sum(v * self.vectors[i].get(k, 0.0) for k, v in qvec.items())
            dset = set(self.docs[i])
            containment = _overlap(qset, dset)
            body_score = 0.75 * cos + 0.25 * containment

            # Titles carry most of the intent, and a one-line user story should
            # still match a verbose blueprint title about the same subject.
            tcos = sum(v * self.title_vectors[i].get(k, 0.0) for k, v in qtvec.items())
            tset = set(self.titles[i])
            tcontain = _overlap(qtset, tset)
            title_score = 0.7 * tcos + 0.3 * tcontain

            score = max(body_score, 0.95 * title_score)
            reason = f"tfidf={cos:.2f}, title={tcos:.2f}, overlap={containment:.2f}"
            if qemb is not None and self.embeddings:
                emb = _cosine(qemb, self.embeddings[i])
                score = max(score, 0.7 * emb + 0.3 * title_score)
                reason += f", embedding={emb:.2f}"
            if score > 0.05:
                scored.append(Match(t.id, t.title, round(score, 3), reason, t.sprint))

        scored.sort(key=lambda m: -m.score)
        return scored[:top_k]


def _overlap(a: set[str], b: set[str]) -> float:
    """Containment when one side is much shorter (a terse user story against a
    verbose ticket), Jaccard otherwise — so two templated titles about
    different subjects do not look identical just because they share verbs."""
    if not a or not b:
        return 0.0
    inter = len(a & b)
    shorter, longer = min(len(a), len(b)), max(len(a), len(b))
    if shorter < 0.6 * longer:
        return inter / shorter
    return inter / len(a | b)


def _cosine(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a)) or 1.0
    nb = math.sqrt(sum(y * y for y in b)) or 1.0
    return dot / (na * nb)


# --------------------------------------------------------------------------- #
# intake flow
# --------------------------------------------------------------------------- #
def check_new_story(
    backlog: Backlog,
    title: str,
    description: str = "",
    *,
    plan: Plan | None = None,
    points: int = 3,
    duplicate_threshold: float = 0.62,
    review_threshold: float = 0.42,
    embed: EmbedFn | None = None,
) -> IntakeDecision:
    """Check a proposed story against the full original ticket set."""
    index = SimilarityIndex(backlog.leaves, embed=embed)
    text = f"{title}. {description}".strip()
    matches = index.query(text, title=title)
    best = matches[0] if matches else None

    if best and best.score >= duplicate_threshold:
        return IntakeDecision(
            verdict="duplicate",
            message=(
                f"An equivalent ticket already exists: {best.ticket_id} '{best.title}'"
                + (f" (scheduled in Sprint {best.sprint})." if best.sprint else ".")
                + " I have not created a new ticket."
            ),
            matches=matches,
            requires_confirmation=False,
        )

    parent, sprint = _suggest_placement(backlog, plan, matches, points)
    proposed = {
        "title": title,
        "description": description,
        "type": TicketType.STORY.value,
        "parent_id": parent,
        "points": points,
        "source": "user",
        "sad_ref": (backlog.by_id(parent).sad_ref if parent and backlog.by_id(parent) else None),
    }

    if best and best.score >= review_threshold:
        return IntakeDecision(
            verdict="needs_review",
            message=(
                f"This looks close to {best.ticket_id} '{best.title}' (similarity {best.score:.2f}), "
                "but not close enough for me to call it a duplicate. Your call: link to the existing "
                "ticket, or create this as new."
            ),
            matches=matches,
            proposed_ticket=proposed,
            proposed_parent=parent,
            proposed_sprint=sprint,
            confirmation_prompt=f"Create as new under {parent} in Sprint {sprint}? (yes / link-to-existing / cancel)",
        )

    committed_note = ""
    if plan and sprint is not None:
        target = next((s for s in plan.sprints if s.index == sprint), None)
        if target and target.committed:
            committed_note = (
                f" Sprint {sprint} is committed — I will not re-sequence it without your approval; "
                f"the alternative is Sprint {sprint + 1}."
            )

    return IntakeDecision(
        verdict="new",
        message=(
            f"No equivalent ticket found (closest: {best.ticket_id} at {best.score:.2f})."
            if best else "No equivalent ticket found."
        )
        + f" Suggested home: {parent or 'unassigned'}, Sprint {sprint}." + committed_note,
        matches=matches,
        proposed_ticket=proposed,
        proposed_parent=parent,
        proposed_sprint=sprint,
        confirmation_prompt=f"Create this ticket under {parent} and place it in Sprint {sprint}? (yes / no)",
    )


def _suggest_placement(
    backlog: Backlog, plan: Plan | None, matches: list[Match], points: int
) -> tuple[str | None, int | None]:
    parent = None
    if matches:
        nearest = backlog.by_id(matches[0].ticket_id)
        parent = nearest.parent_id if nearest else None
    if parent is None:
        features = backlog.of_type(TicketType.FEATURE)
        parent = features[0].id if features else None

    if plan is None:
        return parent, None

    for s in plan.sprints:
        if s.committed:
            continue
        load = sum(_pts(backlog, t) for t in s.ticket_ids)
        if load + points <= s.capacity:
            return parent, s.index
    return parent, (plan.sprints[-1].index + 1 if plan.sprints else 1)


def _pts(backlog: Backlog, ticket_id: str) -> int:
    t = backlog.by_id(ticket_id)
    return t.points if t else 0


def confirm_and_create(
    backlog: Backlog,
    decision: IntakeDecision,
    *,
    plan: Plan | None = None,
    approved: bool,
    approver: str = "unknown",
) -> Ticket | None:
    """Nothing is written until a human approves. Returns the created ticket."""
    if not approved or decision.verdict == "duplicate" or not decision.proposed_ticket:
        return None

    spec = decision.proposed_ticket
    new_id = f"USER-{sum(1 for t in backlog.tickets if t.source == 'user') + 1:03d}"
    ticket = Ticket(
        id=new_id,
        title=spec["title"],
        type=TicketType.STORY,
        parent_id=spec.get("parent_id"),
        description=spec.get("description", ""),
        sad_ref=spec.get("sad_ref"),
        points=int(spec.get("points", 3)),
        acceptance_criteria=["Behaviour agreed with the Product Owner is demonstrable"],
        definition_of_done=dod_for(Category.FUNCTIONAL),
        sprint=decision.proposed_sprint,
        source="user",
        status="planned",
        rationale=f"Added mid-flight by {approver}; placed by similarity to existing scope.",
    )
    parent = backlog.by_id(ticket.parent_id or "")
    if parent:
        ticket.layer = parent.layer
    backlog.add(ticket)

    if plan and decision.proposed_sprint is not None:
        target = next((s for s in plan.sprints if s.index == decision.proposed_sprint), None)
        if target is None:
            start, end = None, None
            last = plan.sprints[-1] if plan.sprints else None
            if last:
                start, end = last.end, last.end
            target = Sprint(index=decision.proposed_sprint, start=start or last.start,
                            end=end or last.end, capacity=last.capacity if last else 0)
            plan.sprints.append(target)
        target.ticket_ids.append(ticket.id)
    return ticket
