"""Capability 2 — enforce and inspect the SAFe hierarchy.

Epic -> Feature -> Story/Task, parent-child links preserved, every leaf
independently estimable with acceptance criteria and a Definition of Done.
`validate` is the gate: if it returns issues, the backlog is not ready.
"""

from __future__ import annotations

from typing import Any

from .common import count_by
from .models import Backlog, Ticket, TicketType

_ALLOWED_PARENT: dict[TicketType, set[TicketType]] = {
    TicketType.EPIC: set(),
    TicketType.FEATURE: {TicketType.EPIC},
    TicketType.STORY: {TicketType.FEATURE, TicketType.EPIC},
    TicketType.TASK: {TicketType.FEATURE, TicketType.EPIC, TicketType.STORY},
    TicketType.SPIKE: {TicketType.FEATURE, TicketType.EPIC},
}


def validate(backlog: Backlog) -> list[dict[str, str]]:
    """Return a list of readiness violations (empty list == ready)."""
    issues: list[dict[str, str]] = []
    index = {t.id: t for t in backlog.tickets}

    for t in backlog.tickets:
        if t.type is TicketType.EPIC:
            if t.parent_id:
                issues.append(_issue(t, "epic_has_parent", "Epics must sit at the top of the tree"))
        else:
            parent = index.get(t.parent_id or "")
            if parent is None:
                issues.append(_issue(t, "orphan", "No parent in the hierarchy"))
            elif parent.type not in _ALLOWED_PARENT[t.type]:
                issues.append(_issue(t, "bad_parent_type", f"{t.type.value} cannot hang off {parent.type.value}"))

        if not t.sad_ref:
            issues.append(_issue(t, "no_traceability", "No S-AD section reference"))

        if t.type in (TicketType.STORY, TicketType.TASK, TicketType.SPIKE):
            if t.points <= 0:
                issues.append(_issue(t, "unestimated", "Leaf ticket has no story points"))
            if t.points > 13:
                issues.append(_issue(t, "too_large", "Leaf exceeds 13 points — split before committing"))
            if not t.acceptance_criteria:
                issues.append(_issue(t, "no_acceptance_criteria", "Leaf has no acceptance criteria"))
            if not t.definition_of_done:
                issues.append(_issue(t, "no_dod", "Leaf has no Definition of Done"))

        for dep in t.depends_on:
            if dep not in index:
                issues.append(_issue(t, "dangling_dependency", f"Depends on unknown ticket {dep}"))

    for epic in backlog.of_type(TicketType.EPIC):
        if not backlog.children_of(epic.id):
            issues.append(_issue(epic, "empty_epic", "Epic has no features or stories"))
    for feature in backlog.of_type(TicketType.FEATURE):
        if not backlog.children_of(feature.id):
            issues.append(_issue(feature, "empty_feature", "Feature has no stories"))

    return issues


def _issue(t: Ticket, code: str, detail: str) -> dict[str, str]:
    return {"ticket_id": t.id, "title": t.title, "code": code, "detail": detail}


def rollup_points(backlog: Backlog) -> Backlog:
    """Sum leaf points into Features, then Features into Epics."""
    for feature in backlog.of_type(TicketType.FEATURE):
        feature.points = sum(c.points for c in backlog.children_of(feature.id))
    for epic in backlog.of_type(TicketType.EPIC):
        epic.points = sum(c.points for c in backlog.children_of(epic.id))
    return backlog


def tree(backlog: Backlog) -> list[dict[str, Any]]:
    """Nested structure for a UI board / export."""

    def node(t: Ticket) -> dict[str, Any]:
        d = t.to_dict()
        kids = backlog.children_of(t.id)
        if kids:
            d["children"] = [node(k) for k in kids]
        return d

    return [node(e) for e in backlog.of_type(TicketType.EPIC)]


def stats(backlog: Backlog) -> dict[str, Any]:
    return {
        "epics": len(backlog.of_type(TicketType.EPIC)),
        "features": len(backlog.of_type(TicketType.FEATURE)),
        "leaves": len(backlog.leaves),
        "total_points": sum(t.points for t in backlog.leaves),
        "by_layer": count_by(t.layer for t in backlog.leaves),
        "by_category": count_by(t.category.value for t in backlog.leaves),
    }

