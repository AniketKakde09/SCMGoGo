"""Parse a System Architecture Document into addressable, layer-tagged sections.

Accepts .docx, .md, or .txt. Every ticket produced later carries the id of the
section it came from, which is what gives you S-AD traceability for free.
"""

from __future__ import annotations

import re
from pathlib import Path

from .models import SADSection

_MINOR_WORDS = {"and", "or", "of", "the", "a", "an", "for", "to", "in", "on", "with"}

_HEADING_RE = re.compile(
    r"^\s*(?:(?P<num>\d+(?:\.\d+)*)\s*[.):]?\s+)?(?P<title>[A-Z][^\n]{2,90})\s*$"
)
_MD_HEADING_RE = re.compile(r"^(?P<hashes>#{1,4})\s+(?P<title>.+?)\s*$")

_LAYER_HINTS: dict[str, tuple[str, ...]] = {
    "foundation": ("infrastructure", "environment", "ci/cd", "devops", "pipeline",
                   "kubernetes", "deployment", "terraform", "provisioning", "hosting"),
    "data": ("data model", "data architecture", "database", "schema", "persistence",
             "storage", "etl", "ingestion", "master data", "warehouse", "retention", "records"),
    "backend": ("service", "services", "backend", "api", "business logic", "domain",
                "microservice", "processing", "calculate", "engine", "scoring"),
    "integration": ("integration", "integrates", "external system", "messaging", "event stream",
                    "queue", "kafka", "adapter", "third party", "downstream", "upstream",
                    "dealer management system", "telematics"),
    "frontend": ("user interface", "ui", "frontend", "front-end", "ux", "portal",
                 "screen", "web app", "mobile app", "wireframe", "responsive", "wcag", "view"),
    "security": ("security", "authentication", "authorisation", "authorization", "iam",
                 "gdpr", "compliance", "audit", "privacy", "encryption", "tisax",
                 "role-based", "identity provider", "permissions", "personal data"),
    "quality": ("test", "testing", "quality", "qa", "validation", "verification", "coverage"),
    "release": ("release", "rollout", "go-live", "cutover", "monitoring", "alerting",
                "support", "operations", "runbook", "observability"),
}

def classify_layer(text: str, title: str = "") -> str:
    """Score every layer; the title counts triple because it states intent."""
    low = (text or "").lower()
    low_title = (title or "").lower()
    scores: dict[str, int] = {}
    for layer, hints in _LAYER_HINTS.items():
        score = 0
        for hint in hints:
            pattern = r"(?<![a-z])" + re.escape(hint) + r"(?![a-z])"
            score += len(re.findall(pattern, low))
            score += 3 * len(re.findall(pattern, low_title))
        if score:
            scores[layer] = score
    if not scores:
        return "backend"
    return max(scores.items(), key=lambda kv: (kv[1], -list(_LAYER_HINTS).index(kv[0])))[0]


def load_text(path: str | Path) -> str:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return _docx_text(path)
    return path.read_text(encoding="utf-8", errors="ignore")


def _docx_text(path: Path) -> str:
    """Read a .docx without external deps (docx is a zip of XML)."""
    import xml.etree.ElementTree as ET
    import zipfile

    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    with zipfile.ZipFile(path) as z:
        xml = z.read("word/document.xml")
    root = ET.fromstring(xml)
    lines: list[str] = []
    for para in root.iter(f"{{{ns['w']}}}p"):
        text = "".join(node.text or "" for node in para.iter(f"{{{ns['w']}}}t"))
        style = para.find(f".//{{{ns['w']}}}pStyle")
        is_heading = style is not None and "heading" in (style.get(f"{{{ns['w']}}}val") or "").lower()
        if text.strip():
            lines.append(("## " if is_heading else "") + text.strip())
    return "\n".join(lines)


def parse_sad(source: str | Path, *, is_text: bool = False) -> list[SADSection]:
    """Split an S-AD into sections. `source` is a path, or raw text if is_text."""
    text = str(source) if is_text else load_text(source)
    lines = text.splitlines()

    sections: list[SADSection] = []
    current_title: str | None = None
    current_num: str | None = None
    current_level = 1
    buf: list[str] = []

    def flush() -> None:
        if current_title is None:
            return
        body = "\n".join(buf).strip()
        idx = len(sections) + 1
        sid = f"SAD-{current_num}" if current_num else f"SAD-{idx}"
        sections.append(
            SADSection(
                id=sid,
                title=current_title.strip(),
                body=body,
                layer=classify_layer(body[:800], title=current_title),
                level=current_level,
            )
        )

    for raw in lines:
        line = raw.rstrip()
        md = _MD_HEADING_RE.match(line)
        heading_title = heading_num = None
        level = 1
        if md:
            heading_title = md.group("title").strip()
            level = len(md.group("hashes"))
            m = re.match(r"^(\d+(?:\.\d+)*)\s*[.)]?\s+(.*)$", heading_title)
            if m:
                heading_num, heading_title = m.group(1), m.group(2)
        elif _looks_like_plain_heading(line):
            m = _HEADING_RE.match(line)
            heading_title = m.group("title").strip()
            heading_num = m.group("num")
            level = heading_num.count(".") + 1 if heading_num else 1

        if heading_title:
            flush()
            current_title, current_num, current_level = heading_title, heading_num, level
            buf = []
        elif line.strip():
            buf.append(line.strip())

    flush()

    if not sections:  # unstructured input (a one-liner ask, workshop notes)
        sections = [
            SADSection(id="SAD-1", title="Unstructured demand", body=text.strip(),
                       layer=classify_layer(text[:800]))
        ]
    return sections


def _looks_like_plain_heading(line: str) -> bool:
    s = line.strip()
    if not (3 <= len(s) <= 90) or s.endswith((".", ",", ";", ":")):
        return False
    if re.match(r"^\d+(\.\d+)*\s*[.):]?\s+\S", s):
        return True
    words = [w for w in s.split() if w.lower() not in _MINOR_WORDS]
    if not words or len(words) > 10:
        return False
    caps = sum(1 for w in words if w[:1].isupper())
    return caps >= max(2, len(words) - 1)


def summarize(sections: list[SADSection]) -> dict[str, int]:
    out: dict[str, int] = {}
    for s in sections:
        out[s.layer] = out.get(s.layer, 0) + 1
    return out
