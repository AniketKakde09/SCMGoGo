"""AI Scrum Master — S-AD to a dependency-ordered, forecast sprint plan.

    from ai_scrum_master import pipeline
    result = pipeline.run("architecture.docx")
    print(result.summary())
"""

from . import (board, clarify, common, decomposer, dedupe, export, hierarchy,
               llm, pipeline, planner, sad_parser)
from .models import Backlog, CapacityConfig, Category, Sprint, TeamMember, Ticket, TicketType
from .planner import ORDERING_RULE

__all__ = [
    "board", "clarify", "common", "decomposer", "dedupe", "export", "hierarchy", "llm",
    "pipeline", "planner", "sad_parser", "Backlog", "CapacityConfig", "Category",
    "Sprint", "TeamMember", "Ticket", "TicketType", "ORDERING_RULE",
]
__version__ = "0.1.0"
