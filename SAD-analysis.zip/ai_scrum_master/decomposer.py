"""Capability 1 — decompose an S-AD into a complete, traceable ticket set.

Two engines behind one interface:

  * rule engine (always available)   -- layer-aware blueprints per section
  * LLM engine (optional)            -- richer titles/AC, same schema

Both guarantee coverage beyond happy-path functional stories: every Feature
gets QA, every risk-bearing Feature gets a security/compliance ticket, every
Epic gets release work, and the architecture gets foundation enablers. That is
the difference between "we have an S-AD" and "we have a shippable service".
"""

from __future__ import annotations

import re
from . import llm
from .common import dod_for, unique
from .models import Backlog, Category, SADSection, Ticket, TicketType

_FIB = [1, 2, 3, 5, 8, 13]

_REQ_HINT = re.compile(
    r"\b(shall|must|should|will|support|provide|enable|allow|expose|store|"
    r"validate|ingest|render|integrate|authenticate|report|track|calculate)\b",
    re.I,
)

_RISK_HINT = re.compile(
    r"\b(integration|migration|legacy|security|compliance|gdpr|performance|"
    r"scal|real-?time|third[- ]party|encryption|pii|sso|payment)\b",
    re.I,
)

# layer -> ordered story blueprint. Order inside a layer is itself a dependency
# chain (wireframes before HTML, schema before endpoint, contract before client).
_BLUEPRINT: dict[str, list[tuple[str, Category, int]]] = {
    "foundation": [
        ("Provision {x} environment and baseline configuration", Category.ENABLER, 5),
        ("Automate build & deployment pipeline for {x}", Category.ENABLER, 5),
        ("Set up logging, metrics and alerting for {x}", Category.ENABLER, 3),
    ],
    "data": [
        ("Design data model for {x}", Category.FUNCTIONAL, 3),
        ("Implement schema and migrations for {x}", Category.FUNCTIONAL, 5),
        ("Implement data access layer for {x}", Category.FUNCTIONAL, 3),
        ("Seed and validate reference data for {x}", Category.FUNCTIONAL, 2),
    ],
    "backend": [
        ("Define service contract for {x}", Category.FUNCTIONAL, 2),
        ("Implement core business logic for {x}", Category.FUNCTIONAL, 5),
        ("Expose API endpoints for {x}", Category.FUNCTIONAL, 3),
        ("Add validation, error handling and resilience to {x}", Category.FUNCTIONAL, 3),
    ],
    "integration": [
        ("Define integration contract for {x}", Category.FUNCTIONAL, 3),
        ("Implement adapter/client for {x}", Category.FUNCTIONAL, 5),
        ("Implement retries, idempotency and dead-letter handling for {x}", Category.FUNCTIONAL, 3),
        ("Build contract tests for {x}", Category.QA, 3),
    ],
    "frontend": [
        ("Produce UI wireframes for {x}", Category.FUNCTIONAL, 2),
        ("Review and sign off wireframes for {x}", Category.FUNCTIONAL, 1),
        ("Implement {x} UI components in HTML/React", Category.FUNCTIONAL, 5),
        ("Wire {x} UI to backend APIs", Category.FUNCTIONAL, 3),
        ("Accessibility and responsive pass for {x}", Category.QA, 3),
    ],
    "security": [
        ("Define security controls for {x}", Category.SECURITY, 3),
        ("Implement authentication/authorization for {x}", Category.SECURITY, 5),
        ("Implement audit logging and data-retention rules for {x}", Category.COMPLIANCE, 3),
    ],
    "quality": [
        ("Define test strategy and coverage targets for {x}", Category.QA, 2),
        ("Automate regression suite for {x}", Category.QA, 5),
        ("Run performance and load validation for {x}", Category.QA, 3),
    ],
    "release": [
        ("Prepare release runbook and rollback plan for {x}", Category.RELEASE, 3),
        ("Execute go-live readiness review for {x}", Category.RELEASE, 2),
        ("Set up post-release monitoring and support handover for {x}", Category.RELEASE, 3),
    ],
}

# Cross-cutting epics appended when the S-AD does not already cover them.
_CROSS_CUTTING = [
    ("Quality Engineering", "quality", ["Test automation framework", "Regression and performance validation"]),
    ("Security & Compliance", "security", ["Identity and access management", "Data protection and auditability"]),
    ("Release & Operations", "release", ["Release engineering", "Operational readiness"]),
]


class _Ids:
    def __init__(self) -> None:
        self.n: dict[str, int] = {}

    def next(self, prefix: str) -> str:
        self.n[prefix] = self.n.get(prefix, 0) + 1
        width = 2 if prefix == "EPIC" else (3 if prefix == "FEAT" else 4)
        return f"{prefix}-{self.n[prefix]:0{width}d}"


def decompose(
    sections: list[SADSection],
    *,
    min_leaf_tickets: int = 100,
    use_llm: bool = True,
) -> Backlog:
    """Turn parsed S-AD sections into a full Epic/Feature/Story backlog."""
    backlog = Backlog(sad_sections=list(sections))
    ids = _Ids()

    for epic_section, child_sections in _group_sections(sections):
        epic = _make_epic(ids, epic_section)
        backlog.add(epic)
        feature_specs = _dedupe_specs(_feature_specs(epic_section, child_sections, use_llm=use_llm))
        used_requirements: set[str] = set()
        for spec in feature_specs:
            spec["_used"] = used_requirements
            feature = _make_feature(ids, epic, spec["title"], spec["section"])
            backlog.add(feature)
            for ticket in _stories_for(ids, feature, spec, use_llm=use_llm):
                backlog.add(ticket)
            backlog.add(_qa_ticket(ids, feature))
            if _needs_security(feature, spec):
                backlog.add(_security_ticket(ids, feature))
        backlog.add(_epic_release_ticket(ids, epic))

    _add_cross_cutting(backlog, ids)
    _top_up(backlog, ids, min_leaf_tickets)
    return backlog


# --------------------------------------------------------------------------- #
# section grouping
# --------------------------------------------------------------------------- #
def _group_sections(sections: list[SADSection]) -> list[tuple[SADSection, list[SADSection]]]:
    groups: list[tuple[SADSection, list[SADSection]]] = []
    current: SADSection | None = None
    children: list[SADSection] = []
    for s in sections:
        if s.level <= 1 or current is None:
            if current is not None:
                groups.append((current, children))
            current, children = s, []
        else:
            children.append(s)
    if current is not None:
        groups.append((current, children))
    return groups


def _feature_specs(
    epic_section: SADSection, child_sections: list[SADSection], *, use_llm: bool
) -> list[dict]:
    specs: list[dict] = []
    for child in child_sections:
        specs.append({"title": child.title, "section": child, "requirements": _requirements(child.body)})
    if not specs:
        for item in _capabilities(epic_section, use_llm=use_llm):
            specs.append({"title": item, "section": epic_section, "requirements": _requirements(epic_section.body)})
    return specs


def _capabilities(section: SADSection, *, use_llm: bool) -> list[str]:
    """Feature-sized capability names inside a leaf section."""
    if use_llm and llm.available():
        data = llm.complete_json(
            "Read this architecture section and list 2-4 feature-sized capabilities "
            "needed to build it. Return a JSON array of short title strings.\n\n"
            f"### {section.ref}\n{section.body[:3000]}"
        )
        if isinstance(data, list) and data:
            return [str(x)[:90] for x in data[:4]]

    reqs = _requirements(section.body)
    if len(reqs) >= 2:
        return unique(_titleize(r) for r in reqs[:3])
    return [section.title]


def _requirements(body: str) -> list[str]:
    out: list[str] = []
    for raw in re.split(r"(?<=[.;])\s+|\n", body or ""):
        line = raw.strip(" -•*\t")
        if 15 <= len(line) <= 220 and _REQ_HINT.search(line):
            out.append(line)
    return out[:12]


_LEAD_NOISE = re.compile(
    r"^(the|this|a|an)\s+|^(system|service|platform|solution|portal|application|it)\s+"
    r"(shall|must|should|will|can|may)\s+|^(shall|must|should|will)\s+",
    re.I,
)


def _titleize(sentence: str) -> str:
    """Turn a requirement sentence into a readable feature/story name."""
    text = re.sub(r"\s+", " ", sentence or "").strip().rstrip(".")
    previous = None
    while previous != text:                       # strip nested lead-ins
        previous = text
        text = _LEAD_NOISE.sub("", text).strip()
    text = re.sub(r"\b(shall|must|should|will|needs? to)\b\s*", "", text, flags=re.I)
    text = re.sub(r"\s{2,}", " ", text).strip()
    text = _short(text, max_words=9, max_chars=64)
    return (text[:1].upper() + text[1:]) if text else "Unnamed capability"


def _short(text: str, *, max_words: int = 7, max_chars: int = 48) -> str:
    """Clip to the first clause, then to a word boundary — no mid-word cuts."""
    clause = re.split(r",| and | including | such as |;", text or "", maxsplit=1)[0].strip()
    if len(clause.split()) < 4:                   # too short to be meaningful
        clause = (text or "").strip()
    words = clause.split()[:max_words]
    out = " ".join(words)
    if len(out) > max_chars:
        out = out[:max_chars].rsplit(" ", 1)[0]
    return out.rstrip(" .,:;-")


# --------------------------------------------------------------------------- #
# ticket builders
# --------------------------------------------------------------------------- #
def _make_epic(ids: _Ids, section: SADSection) -> Ticket:
    return Ticket(
        id=ids.next("EPIC"),
        title=f"{section.title}",
        type=TicketType.EPIC,
        description=(section.body or section.title)[:600],
        sad_ref=section.ref,
        layer=section.layer,
        category=Category.FUNCTIONAL,
        points=0,
        rationale=f"Anchored to S-AD section {section.ref} ({section.layer} layer).",
        definition_of_done=[
            "All child features accepted",
            "Non-functional requirements validated",
            "Architecture decision records updated",
        ],
    )


def _make_feature(ids: _Ids, epic: Ticket, title: str, section: SADSection) -> Ticket:
    return Ticket(
        id=ids.next("FEAT"),
        title=title[:90],
        type=TicketType.FEATURE,
        parent_id=epic.id,
        description=(section.body or title)[:400],
        sad_ref=section.ref,
        layer=section.layer,
        points=0,
        rationale=f"Groups stories delivering '{title}' under epic {epic.id}.",
        definition_of_done=["All child stories done", "Feature demoed to PO", "Docs updated"],
    )


def _stories_for(ids: _Ids, feature: Ticket, spec: dict, *, use_llm: bool) -> list[Ticket]:
    blueprint = _BLUEPRINT.get(feature.layer, _BLUEPRINT["backend"])
    subject = _short(feature.title, max_words=7, max_chars=46)
    tickets: list[Ticket] = []
    previous: Ticket | None = None

    for template, category, points in blueprint:
        t = Ticket(
            id=ids.next("STORY"),
            title=template.format(x=subject)[:110],
            type=TicketType.STORY if category is not Category.ENABLER else TicketType.TASK,
            parent_id=feature.id,
            description=f"Derived from {feature.sad_ref}. {spec.get('requirements', [''])[:1] and spec['requirements'][0] or feature.description[:200]}",
            sad_ref=feature.sad_ref,
            layer=feature.layer,
            category=category,
            points=points,
            risk=_risk_of(f"{template} {feature.description}"),
            acceptance_criteria=_acceptance(template, subject),
            definition_of_done=dod_for(category),
            depends_on=[previous.id] if previous else [],
            rationale=(
                f"Blueprint step for the {feature.layer} layer; "
                + (f"follows {previous.id} because that step produces its input." if previous
                   else f"first step of feature {feature.id}.")
            ),
        )
        tickets.append(t)
        previous = t

    # One extra story per explicit requirement sentence, so nothing in the S-AD
    # text is silently dropped. Skip any that collapse onto an existing sibling.
    seen = {_key(t.title) for t in tickets} | spec.get("_used", set())
    for req in spec.get("requirements", [])[:3]:
        req_key = _key(f"Implement: {_titleize(req)}")
        if req_key in seen:
            continue
        seen.add(req_key)
        if isinstance(spec.get("_used"), set):
            spec["_used"].add(req_key)
        t = Ticket(
            id=ids.next("STORY"),
            title=f"Implement: {_titleize(req)}"[:110],
            type=TicketType.STORY,
            parent_id=feature.id,
            description=req,
            sad_ref=feature.sad_ref,
            layer=feature.layer,
            points=_points_for(req),
            risk=_risk_of(req),
            acceptance_criteria=[
                f"Behaviour described in {feature.sad_ref} is demonstrable",
                "Unit tests cover happy path and at least two error paths",
            ],
            definition_of_done=dod_for(Category.FUNCTIONAL),
            depends_on=[tickets[1].id] if len(tickets) > 1 else [],
            rationale=f"Traces to an explicit requirement statement in {feature.sad_ref}.",
        )
        tickets.append(t)

    if use_llm and llm.available():
        _enrich_with_llm(tickets, feature)
    return tickets


def _enrich_with_llm(tickets: list[Ticket], feature: Ticket) -> None:
    payload = [{"id": t.id, "title": t.title} for t in tickets]
    data = llm.complete_json(
        "For each ticket, write 2-3 testable acceptance criteria in Given/When/Then "
        "style for this architecture feature. Return JSON: "
        '[{"id": "...", "acceptance_criteria": ["..."]}]\n\n'
        f"Feature: {feature.title}\nS-AD section: {feature.sad_ref}\n"
        f"Context: {feature.description[:1200]}\nTickets: {payload}"
    )
    if not isinstance(data, list):
        return
    index = {t.id: t for t in tickets}
    for row in data:
        t = index.get(str(row.get("id", "")))
        ac = row.get("acceptance_criteria")
        if t and isinstance(ac, list) and ac:
            t.acceptance_criteria = [str(x)[:200] for x in ac[:4]]


def _qa_ticket(ids: _Ids, feature: Ticket) -> Ticket:
    return Ticket(
        id=ids.next("STORY"),
        title=f"Automated test coverage for {feature.title}"[:110],
        type=TicketType.TASK,
        parent_id=feature.id,
        description=f"End-to-end and integration tests proving {feature.title} meets {feature.sad_ref}.",
        sad_ref=feature.sad_ref,
        layer="quality",
        category=Category.QA,
        points=3,
        acceptance_criteria=[
            "Automated suite runs in CI on every merge",
            "Coverage threshold agreed with the team is met",
            "Failures block the pipeline",
        ],
        definition_of_done=dod_for(Category.QA),
        rationale=f"Quality gate for feature {feature.id}; depends on its implementation stories.",
    )


def _security_ticket(ids: _Ids, feature: Ticket) -> Ticket:
    return Ticket(
        id=ids.next("STORY"),
        title=f"Security & compliance review for {feature.title}"[:110],
        type=TicketType.TASK,
        parent_id=feature.id,
        description=f"Threat model, control mapping and data-protection review for {feature.sad_ref}.",
        sad_ref=feature.sad_ref,
        layer="security",
        category=Category.SECURITY,
        points=3,
        risk=3,
        acceptance_criteria=[
            "Threat model documented and reviewed",
            "Controls mapped to the applicable policy/regulation",
            "Findings triaged with owners and due dates",
        ],
        definition_of_done=dod_for(Category.SECURITY),
        rationale=f"Feature {feature.id} handles risk-bearing behaviour, so it needs an explicit control review.",
    )


def _epic_release_ticket(ids: _Ids, epic: Ticket) -> Ticket:
    return Ticket(
        id=ids.next("STORY"),
        title=f"Release readiness for {epic.title}"[:110],
        type=TicketType.TASK,
        parent_id=epic.id,
        description=f"Runbook, rollback plan and go-live checks for {epic.sad_ref}.",
        sad_ref=epic.sad_ref,
        layer="release",
        category=Category.RELEASE,
        points=3,
        acceptance_criteria=[
            "Runbook and rollback plan reviewed",
            "Monitoring and alerting verified in pre-prod",
            "Support handover completed",
        ],
        definition_of_done=dod_for(Category.RELEASE),
        rationale=f"Closes out epic {epic.id}; sequenced after all of its stories.",
    )


def _add_cross_cutting(backlog: Backlog, ids: _Ids) -> None:
    present = {t.layer for t in backlog.of_type(TicketType.EPIC)}
    anchor = backlog.sad_sections[0].ref if backlog.sad_sections else "SAD-1"
    for name, layer, features in _CROSS_CUTTING:
        if layer in present:
            continue
        section = SADSection(id=f"SAD-X-{layer}", title=name, body=name, layer=layer)
        epic = _make_epic(ids, section)
        epic.title = name
        epic.rationale = (
            f"The S-AD has no dedicated {layer} section, but a shippable product still "
            f"needs this work; anchored to {anchor} as cross-cutting scope."
        )
        backlog.add(epic)
        for fname in features:
            feature = _make_feature(ids, epic, fname, section)
            backlog.add(feature)
            for t in _stories_for(ids, feature, {"requirements": []}, use_llm=False):
                backlog.add(t)
            backlog.add(_qa_ticket(ids, feature))
        backlog.add(_epic_release_ticket(ids, epic))


def _top_up(backlog: Backlog, ids: _Ids, target: int) -> None:
    """Guarantee the '100+ tickets' bar without inventing meaningless work:
    deepen existing features with named hardening/enabler stories."""
    extras = [
        ("Refactor and document {x}", Category.FUNCTIONAL, 2, "backend"),
        ("Observability instrumentation for {x}", Category.ENABLER, 2, "foundation"),
        ("Exploratory test charter for {x}", Category.QA, 2, "quality"),
    ]
    features = backlog.of_type(TicketType.FEATURE)
    i = 0
    while len(backlog.leaves) < target and features and i < len(features) * len(extras):
        feature = features[i % len(features)]
        template, category, points, layer = extras[i // len(features) % len(extras)]
        backlog.add(
            Ticket(
                id=ids.next("STORY"),
                title=template.format(x=feature.title)[:110],
                type=TicketType.TASK,
                parent_id=feature.id,
                description=f"Hardening work required before {feature.title} is production-ready.",
                sad_ref=feature.sad_ref,
                layer=layer,
                category=category,
                points=points,
                acceptance_criteria=["Reviewed by a second engineer", "No open critical findings"],
                definition_of_done=dod_for(category),
                rationale=f"Completes the path to production for feature {feature.id}.",
            )
        )
        i += 1


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _key(title: str) -> str:
    return re.sub(r"[^a-z0-9 ]", "", (title or "").lower()).strip()


def _dedupe_specs(specs: list[dict]) -> list[dict]:
    out, seen = [], set()
    for spec in specs:
        k = _key(spec["title"])
        if not k or k in seen or len(k.split()) < 2:
            continue
        seen.add(k)
        out.append(spec)
    return out or specs[:1]


def _needs_security(feature: Ticket, spec: dict) -> bool:
    text = f"{feature.title} {feature.description}"
    return feature.layer in {"data", "integration", "security", "backend"} or bool(_RISK_HINT.search(text))


def _risk_of(text: str) -> int:
    hits = len(_RISK_HINT.findall(text or ""))
    return max(1, min(5, 1 + hits))


def _points_for(text: str) -> int:
    n = len(text or "")
    idx = 0 if n < 40 else 1 if n < 80 else 2 if n < 140 else 3
    if _RISK_HINT.search(text or ""):
        idx += 1
    return _FIB[min(idx, len(_FIB) - 1)]


def _acceptance(template: str, subject: str) -> list[str]:
    low = template.lower()
    if "wireframe" in low and "sign off" not in low:
        return [
            f"Wireframes cover every screen state for {subject} (empty, loading, error)",
            "Wireframes reviewed against the design system",
        ]
    if "sign off" in low:
        return ["PO and UX have approved the wireframes", "Open comments resolved or logged as follow-ups"]
    if "ui components" in low:
        return [
            "UI matches the approved wireframes",
            "Component renders correct states from mocked data",
            "No console errors; lint and type checks pass",
        ]
    if "schema" in low or "data model" in low:
        return [
            "Entities, keys and relationships documented",
            "Migration applies and rolls back cleanly on a copy of the dataset",
        ]
    if "api" in low or "contract" in low:
        return [
            "Contract published (OpenAPI/schema) and reviewed",
            "Endpoint returns documented status codes for success and failure",
        ]
    return [
        f"{subject} behaves as described in the referenced S-AD section",
        "Automated tests cover the new behaviour",
    ]
