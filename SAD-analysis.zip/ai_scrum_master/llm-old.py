"""Thin, optional LLM adapter.

The whole pipeline runs deterministically without it. If ANTHROPIC_API_KEY is
set and the SDK is installed, the decomposer and the clarifier use it for
richer output; otherwise every call returns None and callers fall back to the
rule engine. Nothing in the system *requires* a model to be reachable.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any

MODEL = os.environ.get("ASM_MODEL", "claude-sonnet-4-6")


def available() -> bool:
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return False
    try:
        import anthropic  # noqa: F401
    except ImportError:
        return False
    return True


def complete(prompt: str, *, system: str = "", max_tokens: int = 4000) -> str | None:
    if not available():
        return None
    try:
        import anthropic

        client = anthropic.Anthropic()
        msg = client.messages.create(
            model=MODEL,
            max_tokens=max_tokens,
            system=system or "You are a senior Scrum Master and solution architect.",
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(b.text for b in msg.content if b.type == "text")
    except Exception:  # network off, rate limit, bad key -> fall back silently
        return None


def complete_json(prompt: str, *, system: str = "", max_tokens: int = 4000) -> Any | None:
    raw = complete(
        prompt + "\n\nRespond with JSON only. No prose, no markdown fences.",
        system=system,
        max_tokens=max_tokens,
    )
    if not raw:
        return None
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        m = re.search(r"(\[.*\]|\{.*\})", cleaned, flags=re.DOTALL)
        if not m:
            return None
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            return None
