"""Health check, refinement and balancing for an *existing* board.

Load the synthetic board (xlsx/csv/json) and get findings detected by logic —
joins, graph checks, similarity — never by hard-coded record ids.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .common import count_by, find_cycles
from .dedupe import SimilarityIndex, _overlap, normalize
from .models import Backlog, Category, Ticket, TicketType

_FIELD_ALIASES = {
    "id": ("id", "key", "issue key", "ticket", "ticket id"),
    "title": ("title", "summary", "name", "story"),
    "type": ("type", "issue type", "issuetype", "level"),
    "parent_id": ("parent", "parent id", "parent key", "epic link"),
    "points": ("points", "story points", "estimate", "sp"),
    "sprint": ("sprint", "iteration"),
    "status": ("status", "state"),
    "description": ("description", "details", "acceptance criteria"),
    "depends_on": ("depends on", "blocked by", "dependencies"),
}


def load_board(path: str | Path) -> Backlog:
    path = Path(path)
    if path.suffix.lower() in {".xlsx", ".xlsm"}:
        rows = _read_xlsx(path)
    elif path.suffix.lower() == ".json":
        rows = json.loads(path.read_text())
    else:
        with path.open(newline="", encoding="utf-8-sig") as fh:
            rows = list(csv.DictReader(fh))
    return _rows_to_backlog(rows)


def _read_xlsx(path: Path) -> list[dict[str, Any]]:
    try:
        import openpyxl  # optional
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("openpyxl is required to read .xlsx boards") from exc
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[wb.sheetnames[0]]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    header = [str(h or "").strip() for h in rows[0]]
    return [dict(zip(header, r)) for r in rows[1:] if any(v is not None for v in r)]


def _pick(row: dict[str, Any], field: str) -> Any:
    lower = {str(k).strip().lower(): v for k, v in row.items() if k}
    for alias in _FIELD_ALIASES[field]:
        if alias in lower and lower[alias] not in (None, ""):
            return lower[alias]
    return None


def _rows_to_backlog(rows: list[dict[str, Any]]) -> Backlog:
    backlog = Backlog()
    for i, row in enumerate(rows, start=1):
        raw_type = str(_pick(row, "type") or "Story").strip().lower()
        ttype = {
            "epic": TicketType.EPIC, "feature": TicketType.FEATURE,
            "task": TicketType.TASK, "spike": TicketType.SPIKE,
        }.get(raw_type, TicketType.STORY)
        deps = _pick(row, "depends_on")
        dep_list = [d.strip() for d in str(deps).replace(";", ",").split(",") if d.strip()] if deps else []
        backlog.add(
            Ticket(
                id=str(_pick(row, "id") or f"BOARD-{i:04d}"),
                title=str(_pick(row, "title") or "(untitled)"),
                type=ttype,
                parent_id=str(_pick(row, "parent_id")) if _pick(row, "parent_id") else None,
                description=str(_pick(row, "description") or ""),
                points=_as_int(_pick(row, "points")),
                sprint=_as_int(_pick(row, "sprint")) or None,
                status=str(_pick(row, "status") or "unknown"),
                depends_on=dep_list,
                source="board",
            )
        )
    return backlog


def _as_int(v: Any) -> int:
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def health_check(backlog: Backlog, *, duplicate_threshold: float = 0.82) -> dict[str, Any]:
    findings: list[dict[str, Any]] = []
    index = {t.id: t for t in backlog.tickets}

    for t in backlog.tickets:
        if t.type in (TicketType.STORY, TicketType.TASK) and t.points <= 0:
            findings.append(_f("unestimated", t, "Leaf ticket has no estimate"))
        if t.points > 13 and t.type in (TicketType.STORY, TicketType.TASK, TicketType.SPIKE):
            findings.append(_f("oversized", t, f"{t.points} points — split before commitment"))
        if t.type is not TicketType.EPIC and not t.parent_id:
            findings.append(_f("orphan", t, "No parent link — breaks the SAFe hierarchy"))
        if t.parent_id and t.parent_id not in index:
            findings.append(_f("broken_parent", t, f"Parent {t.parent_id} does not exist on the board"))
        if len(t.title.split()) < 3 and t.type is not TicketType.EPIC:
            findings.append(_f("thin_title", t, "Title too vague to refine"))
        if not t.description:
            findings.append(_f("no_detail", t, "No description or acceptance criteria"))
        for dep in t.depends_on:
            d = index.get(dep)
            if d is None:
                findings.append(_f("dangling_dependency", t, f"Blocked by unknown {dep}"))
            elif t.sprint and d.sprint and d.sprint >= t.sprint:
                findings.append(
                    _f("dependency_inversion", t,
                       f"Scheduled in sprint {t.sprint} but blocked by {dep} in sprint {d.sprint}")
                )

    findings.extend(_cycles(backlog))
    findings.extend(_semantic_duplicates(backlog, duplicate_threshold))

    balance = _sprint_balance(backlog)
    return {
        "ticket_count": len(backlog.tickets),
        "findings": findings,
        "findings_by_code": count_by(f["code"] for f in findings),
        "sprint_balance": balance,
        "refinement_queue": list(dict.fromkeys(
            f["ticket_id"] for f in findings
            if f["code"] in {"unestimated", "no_detail", "thin_title", "oversized"}
        ))[:50],
    }


def _f(code: str, t: Ticket, detail: str) -> dict[str, Any]:
    return {"code": code, "ticket_id": t.id, "title": t.title, "detail": detail, "sprint": t.sprint}


def _cycles(backlog: Backlog) -> list[dict[str, Any]]:
    index = {t.id: t for t in backlog.tickets}
    edges = {t.id: [d for d in t.depends_on if d in index] for t in backlog.tickets}
    return [
        {"code": "dependency_cycle", "ticket_id": node, "title": index[node].title,
         "detail": "Cycle: " + " -> ".join(path), "sprint": index[node].sprint}
        for node, _dep, path in find_cycles(edges)
    ]


def _semantic_duplicates(backlog: Backlog, threshold: float) -> list[dict[str, Any]]:
    tickets = backlog.leaves or backlog.tickets
    index = SimilarityIndex(tickets)
    seen: set[tuple[str, str]] = set()
    out: list[dict[str, Any]] = []
    lookup = {x.id: x for x in tickets}
    for t in tickets:
        for m in index.query(t.text(), title=t.title, top_k=3):
            other = lookup.get(m.ticket_id)
            if other is None or m.ticket_id == t.id or m.score < threshold:
                continue
            if not _same_work(t, other):
                continue
            key = tuple(sorted((t.id, m.ticket_id)))
            if key in seen:
                continue
            seen.add(key)
            out.append({
                "code": "semantic_duplicate", "ticket_id": t.id, "title": t.title,
                "detail": f"Looks equivalent to {m.ticket_id} '{m.title}' (score {m.score:.2f}; {m.reason})",
                "sprint": t.sprint,
            })
    return out


def _same_work(a: Ticket, b: Ticket) -> bool:
    """Two tickets are the same work only if BOTH the action and the subject
    agree. 'Define the contract for X' and 'Expose the API for X' share a
    subject but are different work — templated backlogs make that mistake easy."""
    ta, tb = normalize(a.title), normalize(b.title)
    if not ta or not tb:
        return False
    if ta[0] not in tb[:3] and tb[0] not in ta[:3]:
        return False                      # different leading verb -> different work
    subj_a, subj_b = set(ta[1:]), set(tb[1:])
    if subj_a and subj_b and _overlap(subj_a, subj_b) < 0.5:
        return False
    return True


def _sprint_balance(backlog: Backlog) -> list[dict[str, Any]]:
    loads: dict[int, list[Ticket]] = {}
    for t in backlog.leaves:
        if t.sprint:
            loads.setdefault(t.sprint, []).append(t)
    if not loads:
        return []
    totals = {s: sum(t.points for t in ts) for s, ts in loads.items()}
    mean = sum(totals.values()) / len(totals)
    return [
        {
            "sprint": s,
            "tickets": len(loads[s]),
            "points": totals[s],
            "variance_vs_mean_pct": round(100 * (totals[s] - mean) / mean, 1) if mean else 0,
            "flag": "overloaded" if totals[s] > mean * 1.25 else ("light" if totals[s] < mean * 0.75 else "ok"),
        }
        for s in sorted(loads)
    ]

