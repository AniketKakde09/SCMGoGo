"""One call that runs the whole agent: raw demand -> questions -> backlog ->
hierarchy -> dependencies -> sprint plan -> forecast -> exports."""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from . import clarify, decomposer, hierarchy, planner, sad_parser
from .models import Backlog, CapacityConfig, TeamMember
from .planner import Plan


@dataclass
class Result:
    backlog: Backlog
    plan: Plan
    questions: list[clarify.Question]
    issues: list[dict[str, str]]
    plan_problems: list[str]

    def summary(self) -> dict[str, Any]:
        return {
            "questions": [q.to_dict() for q in self.questions],
            "hierarchy": hierarchy.stats(self.backlog),
            "coverage": hierarchy.stats(self.backlog)["by_category"],
            "readiness_issues": len(self.issues),
            "ordering_rule": self.plan.ordering_rule,
            "forecast": self.plan.forecast,
            "plan_problems": self.plan_problems,
        }


def default_capacity(start: dt.date | None = None) -> CapacityConfig:
    return CapacityConfig(
        start_date=start or dt.date.today(),
        sprint_length_days=10,
        members=[
            TeamMember("Dev 1"), TeamMember("Dev 2"), TeamMember("Dev 3"),
            TeamMember("Dev 4"), TeamMember("QA 1", role="QA"),
            TeamMember("Scrum Master", allocation=0.3, role="SM"),
        ],
        focus_factor=0.8,
        points_per_person_day=0.8,
    )


def run(
    source: str | Path,
    *,
    is_text: bool = False,
    capacity: CapacityConfig | None = None,
    min_leaf_tickets: int = 100,
    use_llm: bool = True,
    committed_sprints: dict[int, list[str]] | None = None,
) -> Result:
    sections = sad_parser.parse_sad(source, is_text=is_text)
    questions = clarify.clarifying_questions(sections, use_llm=use_llm)

    backlog = decomposer.decompose(sections, min_leaf_tickets=min_leaf_tickets, use_llm=use_llm)
    hierarchy.rollup_points(backlog)
    issues = hierarchy.validate(backlog)

    planner.infer_dependencies(backlog)
    plan = planner.build_plan(backlog, capacity or default_capacity(),
                              committed_sprints=committed_sprints)
    problems = planner.validate_plan(backlog, plan)
    return Result(backlog=backlog, plan=plan, questions=questions,
                  issues=issues, plan_problems=problems)
