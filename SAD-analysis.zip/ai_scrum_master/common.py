"""Helpers that more than one module needs.

Anything in here was previously copy-pasted across two or more modules, which
is how a backlog generator ends up disagreeing with itself about what "done"
means or whether a dependency graph has a cycle.
"""

from __future__ import annotations

from typing import Hashable, Iterable, Mapping, Sequence, TypeVar

from .models import Category

T = TypeVar("T", bound=Hashable)


def count_by(values: Iterable[T]) -> dict[T, int]:
    """Frequency map. Was duplicated verbatim in hierarchy.py and board.py."""
    out: dict[T, int] = {}
    for v in values:
        out[v] = out.get(v, 0) + 1
    return out


def unique(seq: Iterable[T]) -> list[T]:
    """Order-preserving de-duplication."""
    seen: set[T] = set()
    out: list[T] = []
    for x in seq:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


# --------------------------------------------------------------------------- #
# Definition of Done — one source of truth
# --------------------------------------------------------------------------- #
_BASE_DOD = ["Code reviewed and merged", "Automated tests green in CI", "Documentation updated"]

_EXTRA_DOD: dict[Category, list[str]] = {
    Category.QA: ["Test results attached to the ticket"],
    Category.SECURITY: ["Security findings triaged", "Evidence stored for audit"],
    Category.COMPLIANCE: ["Security findings triaged", "Evidence stored for audit"],
    Category.RELEASE: ["Runbook reviewed", "Rollback rehearsed"],
    Category.ENABLER: ["Change is reproducible from code (no manual steps)"],
    Category.FUNCTIONAL: ["Demoed to the Product Owner"],
}


def dod_for(category: Category) -> list[str]:
    """The DoD a ticket of this category must satisfy.

    The decomposer and the mid-sprint intake flow both create tickets; without
    this they drifted apart and user-added stories got a weaker DoD.
    """
    return _BASE_DOD + _EXTRA_DOD.get(category, [])


# --------------------------------------------------------------------------- #
# dependency graph
# --------------------------------------------------------------------------- #
def find_cycles(
    edges: Mapping[str, Sequence[str]]
) -> list[tuple[str, str, list[str]]]:
    """Depth-first scan for back edges.

    Returns `(node, dependency, path)` for every edge that closes a cycle —
    `planner` removes those edges to keep the graph a DAG, `board` reports them
    as findings. Both used to carry their own near-identical DFS.
    """
    state: dict[str, int] = {}
    found: list[tuple[str, str, list[str]]] = []

    def visit(node: str, path: list[str]) -> None:
        state[node] = 1
        for dep in edges.get(node, ()):
            if dep not in edges:
                continue
            if state.get(dep, 0) == 1:
                found.append((node, dep, path + [node, dep]))
            elif state.get(dep, 0) == 0:
                visit(dep, path + [node])
        state[node] = 2

    for node in edges:
        if state.get(node, 0) == 0:
            visit(node, [])
    return found
