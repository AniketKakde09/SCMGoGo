"""Flatten a backlog into the shape the React Flow canvas expects.

The canvas (App.jsx) only understands a 3-level hierarchy — Epic -> Story ->
Sub-task — and it links children to parents by matching `parent` against the
parent's `summary` string (not an id). Our backlog is a proper SAFe tree
(Epic -> Feature -> Story -> Task, arbitrary depth), so this module:

  * keeps depth-0 nodes as "Epic"
  * flattens depth-1 nodes (Feature, or a Story/Task that hangs directly off
    an Epic) into "Story"
  * collapses everything below that (depth >= 2, however deep) into
    "Sub-task", all parented to the nearest depth-1 ancestor

Because the canvas matches purely on the `summary` string, every summary is
made globally unique (duplicate titles get a " (2)", " (3)", ... suffix) —
otherwise two same-named epics/stories would silently merge their children
in the UI.

Works two ways:
  * `canvas_payload_from_tree(tree)`   — pure function over the nested JSON
    produced by `hierarchy.tree()` (or a previously exported backlog_plan
    tree). No live Backlog object required.
  * `canvas_payload(backlog)`          — convenience wrapper for a live run.
"""

from __future__ import annotations

from typing import Any

from .models import Backlog
from . import hierarchy

CANVAS_ISSUE_TYPES = ("Epic", "Story", "Sub-task")


def _dedupe_title(title: str, used: dict[str, int]) -> str:
    title = (title or "Untitled").strip() or "Untitled"
    n = used.get(title, 0)
    used[title] = n + 1
    return title if n == 0 else f"{title} ({n + 1})"


def canvas_payload_from_tree(tree: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert a `hierarchy.tree()`-shaped list of Epic nodes into the flat
    Epic/Story/Sub-task array the canvas's `createDiagram()` consumes.
    """
    used: dict[str, int] = {}
    issues: list[dict[str, Any]] = []

    def walk(node: dict[str, Any], level: int, epic_summary: str | None, story_summary: str | None) -> None:
        raw_title = node.get("title") or node.get("summary") or "Untitled"
        summary = _dedupe_title(raw_title, used)
        children = node.get("children") or []
        description = node.get("description") or node.get("rationale") or ""

        if level == 0:
            issues.append({
                "issue_type": "Epic",
                "summary": summary,
                "description": description,
                "externalId": node.get("id"),
                "sad_ref": node.get("sad_ref"),
            })
            for child in children:
                walk(child, 1, epic_summary=summary, story_summary=None)
            return

        if level == 1:
            issues.append({
                "issue_type": "Story",
                "summary": summary,
                "description": description,
                "parent": epic_summary,
                "story_points": node.get("points"),
                "dependencies": list(node.get("depends_on") or []),
                "acceptance_criteria": list(node.get("acceptance_criteria") or []),
                "externalId": node.get("id"),
                "sad_ref": node.get("sad_ref"),
            })
            for child in children:
                walk(child, 2, epic_summary=epic_summary, story_summary=summary)
            return

        # level >= 2: collapse into a Sub-task under the nearest Story
        issues.append({
            "issue_type": "Sub-task",
            "summary": summary,
            "description": description,
            "parent": story_summary,
            "externalId": node.get("id"),
            "sad_ref": node.get("sad_ref"),
        })
        for child in children:
            walk(child, level + 1, epic_summary=epic_summary, story_summary=story_summary)

    for epic_node in tree:
        walk(epic_node, 0, epic_summary=None, story_summary=None)

    return issues


def canvas_payload(backlog: Backlog) -> list[dict[str, Any]]:
    """Convenience wrapper: build the tree from a live Backlog, then flatten."""
    return canvas_payload_from_tree(hierarchy.tree(backlog))
