"""FastAPI surface for the agent.  uvicorn ai_scrum_master.api:app --reload

Run store is in-memory on purpose: swap `RUNS` for Redis/Postgres when you
outgrow a single process. Nothing here writes to JIRA — /publish/confirm is the
only path that can, and it demands an approver.
"""

from __future__ import annotations

import datetime as dt
import tempfile
import uuid
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from . import board, canvas_export, clarify, dedupe, export, hierarchy, pipeline, planner, sad_parser
from .models import CapacityConfig, TeamMember
from .pipeline import Result

app = FastAPI(title="AI Scrum Master", version="0.1.0")
app.add_middleware(
    CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"]
)

RUNS: dict[str, Result] = {}
DECISIONS: dict[str, dedupe.IntakeDecision] = {}


# --------------------------------------------------------------------------- #
# schemas
# --------------------------------------------------------------------------- #
class TeamMemberIn(BaseModel):
    name: str
    role: str = "Engineer"
    allocation: float = 1.0
    days_off: list[dt.date] = Field(default_factory=list)


class CapacityIn(BaseModel):
    start_date: dt.date | None = None
    sprint_length_days: int = 10
    members: list[TeamMemberIn] = Field(default_factory=list)
    velocity: float | None = None
    focus_factor: float = 0.8
    points_per_person_day: float = 0.8
    holidays: list[dt.date] = Field(default_factory=list)


class GenerateIn(BaseModel):
    text: str | None = None
    min_leaf_tickets: int = 100
    use_llm: bool = True
    capacity: CapacityIn | None = None
    committed_sprints: dict[int, list[str]] = Field(default_factory=dict)


class StoryIn(BaseModel):
    run_id: str
    title: str
    description: str = ""
    points: int = 3


class ConfirmIn(BaseModel):
    run_id: str
    decision_id: str
    approved: bool
    approver: str


class PublishIn(BaseModel):
    run_id: str
    approved_by: str | None = None


class TreeIn(BaseModel):
    tree: list[dict[str, Any]]


def _capacity(cfg: CapacityIn | None) -> CapacityConfig:
    if cfg is None:
        return pipeline.default_capacity()
    return CapacityConfig(
        start_date=cfg.start_date or dt.date.today(),
        sprint_length_days=cfg.sprint_length_days,
        members=[TeamMember(m.name, m.role, m.allocation, list(m.days_off)) for m in cfg.members]
        or pipeline.default_capacity().members,
        velocity=cfg.velocity,
        focus_factor=cfg.focus_factor,
        points_per_person_day=cfg.points_per_person_day,
        holidays=list(cfg.holidays),
    )


def _run(run_id: str) -> Result:
    result = RUNS.get(run_id)
    if result is None:
        raise HTTPException(404, f"Unknown run {run_id}")
    return result


# --------------------------------------------------------------------------- #
# capability 0 — clarify before generating
# --------------------------------------------------------------------------- #
@app.post("/intake/analyze")
def analyze(body: GenerateIn) -> dict[str, Any]:
    if not body.text:
        raise HTTPException(400, "text is required")
    sections = sad_parser.parse_sad(body.text, is_text=True)
    return {
        "sections": [{"id": s.id, "title": s.title, "layer": s.layer, "length": len(s.body)}
                     for s in sections],
        "layer_summary": sad_parser.summarize(sections),
        "clarifying_questions": [q.to_dict() for q in
                                 clarify.clarifying_questions(sections, use_llm=body.use_llm)],
    }


# --------------------------------------------------------------------------- #
# capabilities 1-3
# --------------------------------------------------------------------------- #
@app.post("/backlog/generate")
def generate(body: GenerateIn) -> dict[str, Any]:
    if not body.text:
        raise HTTPException(400, "text is required")
    result = pipeline.run(
        body.text, is_text=True, capacity=_capacity(body.capacity),
        min_leaf_tickets=body.min_leaf_tickets, use_llm=body.use_llm,
        committed_sprints={int(k): v for k, v in body.committed_sprints.items()},
    )
    run_id = uuid.uuid4().hex[:12]
    RUNS[run_id] = result
    return {"run_id": run_id, **result.summary()}


@app.post("/backlog/generate/upload")
async def generate_upload(file: UploadFile = File(...), min_leaf_tickets: int = 100) -> dict[str, Any]:
    suffix = Path(file.filename or "sad.txt").suffix or ".txt"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(await file.read())
        path = tmp.name
    result = pipeline.run(path, min_leaf_tickets=min_leaf_tickets)
    run_id = uuid.uuid4().hex[:12]
    RUNS[run_id] = result
    return {"run_id": run_id, **result.summary()}


@app.get("/backlog/{run_id}")
def get_backlog(run_id: str) -> dict[str, Any]:
    r = _run(run_id)
    return {"stats": hierarchy.stats(r.backlog), "tickets": r.backlog.to_dict()["tickets"]}


@app.get("/backlog/{run_id}/tree")
def get_tree(run_id: str) -> dict[str, Any]:
    return {"tree": hierarchy.tree(_run(run_id).backlog)}


@app.get("/backlog/{run_id}/canvas")
def get_canvas(run_id: str) -> dict[str, Any]:
    """Same backlog as /tree, flattened into the Epic/Story/Sub-task array
    the React Flow canvas (App.jsx) expects — drop-in compatible with the
    `jira_payload` field the frontend already reads from /api/process.
    """
    r = _run(run_id)
    return {
        "status": "complete",
        "run_id": run_id,
        "jira_payload": canvas_export.canvas_payload(r.backlog),
    }


@app.post("/backlog/canvas/from-tree")
def canvas_from_tree(body: TreeIn) -> dict[str, Any]:
    """Same conversion, but for a tree you already have on hand (e.g. a
    saved backlog_plan.json tree, or the output of /backlog/{run_id}/tree)
    rather than a live run_id.
    """
    return {
        "status": "complete",
        "jira_payload": canvas_export.canvas_payload_from_tree(body.tree),
    }


@app.get("/backlog/{run_id}/readiness")
def get_readiness(run_id: str) -> dict[str, Any]:
    r = _run(run_id)
    return {"issues": r.issues, "ready": not r.issues}


@app.get("/plan/{run_id}")
def get_plan(run_id: str) -> dict[str, Any]:
    r = _run(run_id)
    return {"plan": r.plan.to_dict(), "problems": r.plan_problems}


@app.get("/plan/{run_id}/explain/{ticket_id}")
def explain_ticket(run_id: str, ticket_id: str) -> dict[str, Any]:
    r = _run(run_id)
    return {"explanation": planner.explain(r.backlog, ticket_id, r.plan)}


# --------------------------------------------------------------------------- #
# capability 4 — new story check, then human confirmation
# --------------------------------------------------------------------------- #
@app.post("/stories/check")
def check_story(body: StoryIn) -> dict[str, Any]:
    r = _run(body.run_id)
    decision = dedupe.check_new_story(
        r.backlog, body.title, body.description, plan=r.plan, points=body.points
    )
    decision_id = uuid.uuid4().hex[:12]
    DECISIONS[decision_id] = decision
    return {"decision_id": decision_id, **decision.to_dict()}


@app.post("/stories/confirm")
def confirm_story(body: ConfirmIn) -> dict[str, Any]:
    r = _run(body.run_id)
    decision = DECISIONS.get(body.decision_id)
    if decision is None:
        raise HTTPException(404, "Unknown decision")
    ticket = dedupe.confirm_and_create(
        r.backlog, decision, plan=r.plan, approved=body.approved, approver=body.approver
    )
    if ticket is None:
        return {"created": False, "reason": "Not approved, or the story was a duplicate."}
    return {"created": True, "ticket": ticket.to_dict()}


# --------------------------------------------------------------------------- #
# existing board health
# --------------------------------------------------------------------------- #
@app.post("/board/health")
async def board_health(file: UploadFile = File(...)) -> dict[str, Any]:
    suffix = Path(file.filename or "board.csv").suffix or ".csv"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(await file.read())
        path = tmp.name
    existing = board.load_board(path)
    return board.health_check(existing)


@app.get("/board/health/{run_id}")
def board_health_run(run_id: str) -> dict[str, Any]:
    return board.health_check(_run(run_id).backlog)


# --------------------------------------------------------------------------- #
# export + publish gate
# --------------------------------------------------------------------------- #
@app.get("/export/{run_id}")
def export_run(run_id: str, out_dir: str = "exports") -> dict[str, Any]:
    r = _run(run_id)
    return {"files": export.export_all(r.backlog, r.plan, Path(out_dir) / run_id)}


@app.post("/publish/prepare")
def publish_prepare(body: PublishIn) -> dict[str, Any]:
    r = _run(body.run_id)
    payload = export.prepare_publish(r.backlog, r.plan)
    return {k: v for k, v in payload.items() if k != "issues"} | {"preview": payload["issues"][:5]}


@app.post("/publish/confirm")
def publish_confirm(body: PublishIn) -> dict[str, Any]:
    r = _run(body.run_id)
    payload = export.prepare_publish(r.backlog, r.plan)
    return export.publish(payload, approved_by=body.approved_by)
