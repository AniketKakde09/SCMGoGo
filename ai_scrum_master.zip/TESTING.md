# AI Scrum Master — API Testing Guide (curl)

This walks through testing the full pipeline via HTTP, end to end.

## 0. Prerequisites

```bash
cd ai-scrum-master
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

The core pipeline itself has zero third-party dependencies, so `python3 demo.py`
works even with nothing installed. FastAPI/uvicorn are only needed for the
HTTP layer tested below.

Optional — turns on the LLM path (titles/acceptance criteria written by the
model; sequencing, dependencies, and forecasting stay deterministic either way):

```bash
export ANTHROPIC_API_KEY=sk-...     # Windows: set ANTHROPIC_API_KEY=sk-...
export ASM_MODEL=claude-sonnet-4-6  # optional override
```

## 1. Start the server

```bash
uvicorn ai_scrum_master.api:app --reload --port 8000
```

Interactive docs (browse all routes without curl): http://localhost:8000/docs

Tip: pipe any curl call below through `| python3 -m json.tool` or `| jq .`
to pretty-print the JSON response.

## 2. Clarifying questions (no file needed)

Ask the agent to flag ambiguity in a raw S-AD excerpt before anything is generated:

```bash
curl -s localhost:8000/intake/analyze \
  -H 'content-type: application/json' \
  -d '{"text":"1. Scope\nThe portal shall show vehicle health to dealers."}'
```

## 3. Generate the backlog + sprint plan

This is the main entry point. Upload an S-AD file (`.docx` or `.md`) and it
returns a `run_id` you'll reuse in every subsequent call.

```bash
curl -s -F 'file=@S-AD.docx' \
  'localhost:8000/backlog/generate/upload?min_leaf_tickets=100'
```

Capture the run_id automatically (requires `jq`):

```bash
RUN=$(curl -s -F 'file=@S-AD.docx' \
  'localhost:8000/backlog/generate/upload?min_leaf_tickets=100' | jq -r .run_id)
```

Or set it manually from the JSON response:

```bash
RUN=<run_id from step 3>
```

There is also a `/backlog/generate` (JSON body, no file) route — check
`ai_scrum_master/api.py` around line 122 if you want to pass raw text instead
of uploading a document.

## 4. Inspect the generated backlog and plan

```bash
curl -s localhost:8000/backlog/$RUN                    # raw backlog
curl -s localhost:8000/backlog/$RUN/tree               # Epic -> Feature -> Story hierarchy
curl -s localhost:8000/backlog/$RUN/readiness          # DoD / acceptance-criteria / estimate gate
curl -s localhost:8000/plan/$RUN                       # sprints + capacity forecast
curl -s localhost:8000/plan/$RUN/explain/STORY-0063    # why this ticket landed in this sprint
curl -s localhost:8000/export/$RUN                     # csv + json + markdown exports
```

Replace `STORY-0063` with a real ticket ID pulled from the `tree` response —
it's a placeholder.

## 5. Duplicate-check a new story

```bash
curl -s localhost:8000/stories/check \
  -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"title\":\"Draw up the dealer portal screens\",\"points\":3}"
```

Returns a `decision_id` and one of three verdicts: `duplicate`, `needs_review`,
or `new`.

## 6. Human-gated approval

No ticket is ever created without this step:

```bash
curl -s localhost:8000/stories/confirm \
  -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"decision_id\":\"<id from step 5>\",\"approved\":true,\"approver\":\"you@team\"}"
```

## 7. Existing-board health check

```bash
curl -s -F 'file=@board.xlsx' localhost:8000/board/health
```

or, if a run already produced one:

```bash
curl -s localhost:8000/board/health/$RUN
```

## 8. Publish gate (dry run, then approved push)

```bash
curl -s localhost:8000/publish/prepare \
  -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\"}"

curl -s localhost:8000/publish/confirm \
  -H 'content-type: application/json' \
  -d "{\"run_id\":\"$RUN\",\"approved_by\":\"you@team\"}"
```

`publish()` refuses without an `approved_by` value and needs an explicitly
injected transport — there's no code path that reaches JIRA by accident.

## 9. Non-API sanity checks

Run these without the server at all:

```bash
python3 demo.py                      # end-to-end run on the built-in sample S-AD
python3 demo.py path/to/SAD.docx     # your own architecture document
python3 tests/test_agent.py          # 15 checks, no pytest required
pytest tests -q                      # if pytest is installed
```

The repo also ships prior output in `out/` (`backlog.csv`, `backlog_plan.json`,
`sprint_plan.md`) — useful as a reference for expected shape before hitting
the API.

## Notes / gotchas

- Calls in section 4 onward all depend on the `run_id` from step 3, and
  `stories/confirm` depends on the `decision_id` from step 5 — calling out of
  order returns a 404.
- All routes (full list) are in `ai_scrum_master/api.py`:
  `/intake/analyze`, `/backlog/generate`, `/backlog/generate/upload`,
  `/backlog/{run_id}`, `/backlog/{run_id}/tree`, `/backlog/{run_id}/readiness`,
  `/plan/{run_id}`, `/plan/{run_id}/explain/{ticket_id}`, `/stories/check`,
  `/stories/confirm`, `/board/health`, `/board/health/{run_id}`,
  `/export/{run_id}`, `/publish/prepare`, `/publish/confirm`.
