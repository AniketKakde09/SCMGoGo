"""Opt-in sprint preview and explicitly approved Jira sprint assignment.

Does not alter existing forecast, Jira creation, or canvas persistence.
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from hashlib import sha256
import json
import os
import re
import threading
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/api/planning/sprints", tags=["Smart Sprint Planner"])
_PREVIEWS: dict[str, dict[str, Any]] = {}
_LOCK = threading.RLock()
_KEY = re.compile(r"^[A-Z][A-Z0-9_]*-\d+$", re.I)

class Work(BaseModel):
    id: str = Field(min_length=1)
    title: str = ""
    points: float = Field(gt=0, le=10000)
    jira_key: str | None = None
    current_sprint_id: int | None = None
    committed: bool = False
    team: str = "default"

class Sprint(BaseModel):
    id: int = Field(gt=0)
    name: str
    start: date
    end: date
    capacity_points: float = Field(ge=0)
    team: str = "default"
    committed: bool = False

class PreviewRequest(BaseModel):
    tickets: list[Work] = Field(min_length=1, max_length=1000)
    dependencies: list[tuple[str, str]] = Field(default_factory=list)  # prerequisite, dependent
    sprints: list[Sprint] = Field(min_length=1, max_length=100)
    holidays: list[date] = Field(default_factory=list)
    velocity_points: dict[str, float] = Field(default_factory=dict)
    baseline_workdays: int = Field(default=10, ge=1, le=31)

class ApplyRequest(BaseModel):
    preview_id: str
    confirmation: str
    allow_committed_changes: bool = False


def plan(req: PreviewRequest) -> dict[str, Any]:
    tickets = {t.id: t for t in req.tickets}
    if len(tickets) != len(req.tickets):
        raise ValueError("Duplicate ticket IDs")
    sprints = sorted(req.sprints, key=lambda s: (s.start, s.id))
    if len({s.id for s in sprints}) != len(sprints):
        raise ValueError("Duplicate sprint IDs")
    if any(s.end < s.start for s in sprints):
        raise ValueError("Sprint end must not precede start")
    for team, velocity in req.velocity_points.items():
        if velocity <= 0:
            raise ValueError(f"Velocity must be positive for {team}")
    predecessors: dict[str, set[str]] = {key: set() for key in tickets}
    successors: dict[str, set[str]] = {key: set() for key in tickets}
    for before, after in req.dependencies:
        if before not in tickets or after not in tickets or before == after:
            raise ValueError(f"Invalid dependency {before} -> {after}")
        predecessors[after].add(before)
        successors[before].add(after)
    indegree = {key: len(predecessors[key]) for key in tickets}
    ready = sorted(key for key, degree in indegree.items() if degree == 0)
    order = []
    while ready:
        key = ready.pop(0)
        order.append(key)
        for child in sorted(successors[key]):
            indegree[child] -= 1
            if indegree[child] == 0:
                ready.append(child)
                ready.sort()
    if len(order) != len(tickets):
        raise ValueError("Dependency cycle detected; no sprint assignments proposed")
    holidays = set(req.holidays)
    remaining = {}
    capacity_details = []
    for sprint in sprints:
        workdays = sum((sprint.start + timedelta(days=d)).weekday() < 5 and (sprint.start + timedelta(days=d)) not in holidays for d in range((sprint.end-sprint.start).days + 1))
        holiday_adjusted = sprint.capacity_points * min(1, workdays / req.baseline_workdays)
        velocity = req.velocity_points.get(sprint.team)
        effective = min(holiday_adjusted, velocity * min(1, workdays / req.baseline_workdays)) if velocity else holiday_adjusted
        remaining[sprint.id] = round(effective, 4)
        capacity_details.append({"id": sprint.id, "team": sprint.team, "working_days": workdays, "effective_capacity": round(effective, 2), "committed": sprint.committed})
    by_id = {s.id: s for s in sprints}
    assignment: dict[str, int] = {}
    conflicts = []
    # Reserve existing committed work first; never silently reassign it.
    for key in order:
        t = tickets[key]
        if t.committed:
            if t.current_sprint_id not in by_id:
                conflicts.append({"ticket_id": key, "reason": "Committed ticket has no matching sprint in the supplied plan"})
                continue
            s = by_id[t.current_sprint_id]
            if s.team != t.team:
                conflicts.append({"ticket_id": key, "reason": "Committed ticket team does not match sprint"})
                continue
            assignment[key] = s.id
            remaining[s.id] -= t.points
    for key in order:
        t = tickets[key]
        if key in assignment or t.committed:
            continue
        candidates = []
        for s in sprints:
            if s.team != t.team or s.committed or remaining[s.id] + 1e-7 < t.points:
                continue
            if any(parent not in assignment for parent in predecessors[key]):
                continue
            # Finish-to-start: prerequisites must be assigned to a strictly earlier sprint.
            if any(by_id[assignment[parent]].end >= s.start for parent in predecessors[key]):
                continue
            candidates.append(s)
        if candidates:
            chosen = candidates[0]
            assignment[key] = chosen.id
            remaining[chosen.id] -= t.points
        else:
            conflicts.append({"ticket_id": key, "reason": "No feasible unlocked sprint with capacity and completed prerequisites"})
    for key, sprint_id in assignment.items():
        for parent in predecessors[key]:
            if parent in assignment and by_id[assignment[parent]].end >= by_id[sprint_id].start:
                conflicts.append({"ticket_id": key, "reason": f"Prerequisite {parent} does not finish before this sprint"})
    changes = [{"ticket_id": key, "title": tickets[key].title, "jira_key": tickets[key].jira_key, "from_sprint_id": tickets[key].current_sprint_id, "to_sprint_id": target, "committed": tickets[key].committed} for key, target in assignment.items() if tickets[key].current_sprint_id != target]
    finish = max((by_id[sid].end for sid in assignment.values()), default=None)
    return {"heuristic": "dependency-first, risk-aware readiness; earliest unlocked capacity-feasible sprint; strict finish-to-start dependencies", "assignments": assignment, "changes": changes, "conflicts": conflicts, "capacity": capacity_details, "completion_date": finish.isoformat() if finish else None, "unscheduled": [key for key in tickets if key not in assignment], "warnings": ["Forecast is deterministic and conditional on supplied points, sprint dates, capacity, velocity, holidays and dependency completeness.", "Committed work is reserved before new work; over-capacity committed sprints are reported, not changed."] + [f"Committed sprint {s.id} exceeds effective capacity" for s in sprints if s.committed and remaining[s.id] < -1e-7]}

@router.post("/preview")
def preview(req: PreviewRequest):
    try:
        result = plan(req)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    preview_id = uuid.uuid4().hex
    with _LOCK:
        _PREVIEWS[preview_id] = {"request": req, "result": result, "created": datetime.now(timezone.utc), "used": False}
    return {"preview_id": preview_id, **result}


def _jira_session():
    import requests
    from requests.auth import HTTPBasicAuth
    from jira_sync import JIRA_URL, USER_ID, API_TOKEN
    if not USER_ID or not API_TOKEN or "Jiraserver.com" in JIRA_URL:
        raise HTTPException(status_code=503, detail="Jira credentials and URL are not configured")
    session = requests.Session()
    session.auth = HTTPBasicAuth(USER_ID, API_TOKEN)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})
    return session, JIRA_URL

@router.post("/apply")
def apply(req: ApplyRequest):
    if req.confirmation != "SYNC APPROVED SPRINTS":
        raise HTTPException(status_code=400, detail="Explicit confirmation required: SYNC APPROVED SPRINTS")
    with _LOCK:
        record = _PREVIEWS.get(req.preview_id)
        if not record or record["used"] or (datetime.now(timezone.utc) - record["created"]).total_seconds() > 900:
            raise HTTPException(status_code=409, detail="Preview missing, expired, or already applied; generate a new preview")
        result = record["result"]
        if result["conflicts"]:
            raise HTTPException(status_code=409, detail="Resolve all scheduling conflicts before Jira sync")
        changes = [change for change in result["changes"] if change["jira_key"]]
        if any(not _KEY.fullmatch(change["jira_key"]) for change in changes):
            raise HTTPException(status_code=422, detail="Invalid Jira issue key")
        if any(change["committed"] for change in changes) and not req.allow_committed_changes:
            raise HTTPException(status_code=409, detail="Committed sprint change requires separate explicit approval")
    if not changes:
        return {"status": "no_jira_changes", "applied": [], "failed": [], "skipped_drafts": len(result["changes"])}
    session, base = _jira_session()
    # Preflight all target sprints and current Jira sprint state before any mutation.
    from jira_sync import SPRINT_FIELD
    for change in changes:
        key, target = change["jira_key"], change["to_sprint_id"]
        try:
            sr = session.get(f"{base}/rest/agile/1.0/sprint/{target}", timeout=15)
            sr.raise_for_status()
            if sr.json().get("state", "").lower() != "future":
                raise ValueError(f"Target sprint {target} must be future")
            ir = session.get(f"{base}/rest/api/2/issue/{key}", params={"fields": SPRINT_FIELD}, timeout=15)
            ir.raise_for_status()
            field = ir.json().get("fields", {}).get(SPRINT_FIELD)
            # Jira Server can encode sprint metadata as strings; unknown shapes are unsafe.
            if field is not None and not isinstance(field, list):
                raise ValueError(f"Cannot verify current sprint state for {key}; refusing to move")
            for sprint in field or []:
                if not isinstance(sprint, dict):
                    raise ValueError(f"Cannot verify sprint state for {key}; refusing to move")
                if sprint.get("state", "").lower() in ("active", "closed"):
                    if not req.allow_committed_changes:
                        raise ValueError(f"{key} belongs to an active or closed sprint; explicit approval required")
                    if sprint.get("state", "").lower() == "closed":
                        raise ValueError(f"{key} belongs to a closed sprint; manual Jira review required")
        except Exception as exc:
            raise HTTPException(status_code=409, detail=f"Jira preflight failed; nothing changed: {str(exc)[:250]}") from exc
    with _LOCK:
        if record["used"]:
            raise HTTPException(status_code=409, detail="Preview already applied")
        record["used"] = True
    applied, failed = [], []
    for change in changes:
        key, target = change["jira_key"], change["to_sprint_id"]
        try:
            sprint_response = session.get(f"{base}/rest/agile/1.0/sprint/{target}", timeout=15)
            sprint_response.raise_for_status()
            state = sprint_response.json().get("state", "").lower()
            if state != "future":
                raise ValueError(f"Target sprint {target} is {state or 'unknown'}; only future sprints are writable")
            issue_response = session.get(f"{base}/rest/api/2/issue/{key}", params={"fields": "key"}, timeout=15)
            issue_response.raise_for_status()
            response = session.post(f"{base}/rest/agile/1.0/sprint/{target}/issue", json={"issues": [key]}, timeout=20)
            response.raise_for_status()
            applied.append({"jira_key": key, "sprint_id": target})
        except Exception as exc:
            failed.append({"jira_key": key, "sprint_id": target, "error": str(exc)[:300]})
    return {"status": "partial" if failed else "completed", "applied": applied, "failed": failed, "skipped_drafts": len(result["changes"]) - len(changes), "note": "Only existing Jira issues were moved; local draft sprint fields are not automatically changed."}
